import pandas as pd
from datetime import datetime
import os
import time
import math
import socket
import threading
from FUNC import CleanTerminal, RunNewPrompt, ClosePrompts
from FUNC_GUI import OpenGuiInterfaces, OpenGuiCom, OpenGuiRecording

def Experiment(subject_ID, path_subj_folder, filename_terminal_csharp_experiment, path_prompt_csharp_experiment, parameters):

    CleanTerminal()

    
    ###### TIMESTAMP ####################################################
    timestamp_experiment = datetime.now()
    date = f'{str(timestamp_experiment.year)}_{str(timestamp_experiment.month)}_{str(timestamp_experiment.day)}'
    time_test =f'{timestamp_experiment.strftime("%Hh_%Mm_%Ss")}'


    ## Filenames
    filename_xlsx_experiment = f"{subject_ID}_experiment.xlsx"                  
    filename_xlsx_familiarization = "_xlsx_familiarization.xlsx"           
    filename_xlsx_triggers = "_xlsx_triggers_dict.xlsx"
    

    ## Sheets
    sheet_experiment = "Experiment Sequence"
    sheet_time = "Timetable"

    ## Upload of the parameters as a dataframe
    old_path_xlsx_experiment = f'{path_subj_folder}\{filename_xlsx_experiment}'
    new_filename_xlsx_experiment = f"{subject_ID}_experiment_{date}_{time_test}.xlsx"
    new_path_xlsx_experiment= f'{path_subj_folder}\{new_filename_xlsx_experiment}'   
    os.rename(old_path_xlsx_experiment, new_path_xlsx_experiment)

    filename_txt_safety_experiment = f"{subject_ID}_experiment_{date}_{time_test}.txt"


    ###### SAFETY TXT FILE ####################################################
    filepath_safety_txt_experiment = f'{path_subj_folder}\{filename_txt_safety_experiment}'

    with open(filepath_safety_txt_experiment, 'w') as file:
        # Write content to the file
        file.write("")



    ###### STIMULATIONS DATAFRAME ####################################################
    df_stimulation =  pd.read_excel(new_path_xlsx_experiment, sheet_experiment)

    ## Extract commands and surations column
    commands_list = df_stimulation['Command'].to_list()
    dur_column = df_stimulation['Duration'].to_list()


    ###### FAMILIARIZATION DATAFRAME ####################################################
    path_xlsx_familiarization = f'{path_subj_folder}\{filename_xlsx_familiarization}'
    df_familiarization = pd.read_excel(path_xlsx_familiarization)

    ## Extract CUE and PAUSE durarion
    dur_pause = df_familiarization.loc[df_familiarization['Stimulation type'] == 'Pause'].iloc[0, 2].tolist()
    dur_cue = df_familiarization.loc[df_familiarization['Stimulation type'] == 'Cue'].iloc[0, 2].tolist()


    ###### COMBINATIONS' DATA FRAME ####################################################
    ## Extract trigger dictionary from txt file
    df_trigger = pd.DataFrame()

    df_trigger = pd.read_excel(f"{path_subj_folder}\{filename_xlsx_triggers}")
    trigger_start = df_trigger['Trigger'].loc[df_trigger['Trigger name'] == 'Start Experiment'].iloc[0].tolist()
    trigger_stop = df_trigger['Trigger'].loc[df_trigger['Trigger name'] == 'Stop Experiment'].iloc[0].tolist()


    ###### ESTIMATE THE DURATION OF THE EXPEIRMENT ####################################################
    ## Estimate the duration of the experiment
    min_dur_seconds = sum(dur_column) + (dur_cue + dur_pause)*(len(commands_list)- df_stimulation['Block'].value_counts()["BREAK"])
    min_duration_experiment = [math.floor(min_dur_seconds/3600), math.floor((min_dur_seconds%3600)/60), (math.floor((min_dur_seconds%3600)))%60]

    OpenGuiRecording(f"\nEstimated time\n{min_duration_experiment[0]} h {min_duration_experiment[1]} m {min_duration_experiment[2]}s")

    ###### INSERT COM PORT AND START THE RECORDING #################
    answer = OpenGuiCom()
    com_serial = answer[0]
    # flag_diver = answer[1]
    # flag_trigger = answer[2]
    
    print(answer)

    OpenGuiRecording("\nStart recording")

    
    try: 
        prompt = f"{path_prompt_csharp_experiment} --port {com_serial}"
        ClosePrompts(filename_terminal_csharp_experiment)
        RunNewPrompt(prompt)


        ###### THREAD FOR POPUPS AND CLASSIFICATION ####################################################
        print("Creating a second thread  and classification")
        thread = threading.Thread(target = OpenGuiInterfaces,  args =(new_path_xlsx_experiment, filepath_safety_txt_experiment, parameters ))
        thread.start()
        
        time.sleep(3)
        

        ###### SOCKET ####################################################
        ## Create socket with csharp file
        host, port = "127.0.0.1", 5555
        aClientSocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        aClientSocket.connect((host, port))

       

        ###### START EXPERIMENT ####################################################
        while True:  

            ## Send START command to connect the middleware 
            command = f"cmd : {trigger_start} : end "
            print(f'\n\nSTART - Trigger <<{trigger_start}>>')
            aClientSocket.send(command.encode("utf-8"))

            ## Send STIMULATION command
            for cmd in commands_list: 
                aClientSocket.send(cmd.encode("utf-8"))   
                print("Sent command")    
            
            break


    finally:
        ## Send STOP command
        command = f"cmd : {trigger_stop} : end"
        print(f'STOP - Trigger <<{trigger_stop}>>')
        aClientSocket.send(command.encode("utf-8"))


        ## Wait the end of the thread
        thread.join()



        ###### CLASSIFICATION  ####################################################
        from f_Exp_Classification import ExpClassification
        ExpClassification(new_path_xlsx_experiment)

    
        ###### SAVE TIME SHEETS ####################################################
        df_time = pd.DataFrame()
        df_time['Data'] = ['Subject_ID', 'Date', 'Test Time', 'Min Estimated Duration']
        df_time['Time'] = [subject_ID, date, timestamp_experiment.strftime("%H:%M:%S"), f'{min_duration_experiment[0]} h {min_duration_experiment[1]} m {min_duration_experiment[2]}s']
        
        print(df_time)
        
        ## Upload of the parameters as a dataframe
        with pd.ExcelWriter(new_path_xlsx_experiment, mode = 'a', engine='openpyxl', if_sheet_exists='overlay') as workbook:
            df_time.to_excel(workbook, sheet_time, index=False)


        OpenGuiRecording("\nStop recording \nand\n Save")        


        print(f"\n\nEND\n\n ")


# import os
# subject_ID = "subject_p003"
# path_folder_experiment = rf"C:\Users\nicole\Documents\GitHub\ABP_project\EXPERIMENT"
# path_results_folder = rf"{path_folder_experiment}\RESULTS" 
# path_subj_folder = os.path.join(path_results_folder, f"{subject_ID}")
# path_prompt_csharp_experiment = rf"{path_folder_experiment}\Codes\EXP_csharp\bin\Debug\net6.0"
# filename_terminal_csharp_experiment = "EXP_csharp.exe"
# path_prompt_csharp_experiment = rf"{path_prompt_csharp_experiment}\{filename_terminal_csharp_experiment}"
# Experiment(subject_ID, path_subj_folder, filename_terminal_csharp_experiment, path_prompt_csharp_experiment)
