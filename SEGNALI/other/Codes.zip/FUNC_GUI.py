import sys
from PyQt5 import QtWidgets


## Select pc GUI
def OpenGuiPc(): 
    from GUI_pc import PcWindow

    app = QtWidgets.QApplication(sys.argv)
    app.setStyle('Fusion')
    window = PcWindow()
    window.show()
    app.exec_()

    return window.selection


## Import subject ID
def OpenGuiSubjectID(): 
    from GUI_subject_ID import SubjectID

    app = QtWidgets.QApplication(sys.argv)
    app.setStyle('Fusion')
    window = SubjectID()
    window.show()
    app.exec_()

    return window.subject_ID


## Import COM port
def OpenGuiCom(): 
    from GUI_com_arduino import ComArduino

    app = QtWidgets.QApplication(sys.argv)
    app.setStyle('Fusion')
    window = ComArduino()
    window.show()
    app.exec_()

    return window.COMport


## Import COM port
def OpenGuiNumbReps(): 
    from GUI_classification_nreps import NumberRepetitions

    app = QtWidgets.QApplication(sys.argv)
    app.setStyle('Fusion')
    window = NumberRepetitions()
    window.show()
    app.exec_()

    return window.nreps


## Select operation GUI
def OpenGuiSelection(flag_list): 
    from GUI_selection import SelectionWindow

    app = QtWidgets.QApplication(sys.argv)
    app.setStyle('Fusion')
    window = SelectionWindow(flag_list)
    window.show()
    app.exec_()

    return window.selection


## Window subejct's info
def OpenGuiSubjectInfo(): 
    from GUI_subject_info import SubjectInfo

    app = QtWidgets.QApplication(sys.argv)
    app.setStyle('Fusion')
    window = SubjectInfo()
    window.show()
    app.exec_()

    return window.info


## Thimbles
def OpenGuiThimble(): 
    from GUI_thimble import Thimbles

    app = QtWidgets.QApplication(sys.argv)
    app.setStyle('Fusion')
    window = Thimbles()
    window.show()
    app.exec_()

    return window.thimbles_values


## Calibration 
def OpenGuiCalibration(flag_list, color_list, current_force): 
    from GUI_calibration import Calibration

    app = QtWidgets.QApplication(sys.argv)
    app.setStyle('Fusion')
    window = Calibration(flag_list, color_list, current_force)
    window.show()
    app.exec_()

    return window.selection



## Familiarization
def OpenGuiFamiliarization(): 
    from GUI_familiarization import FamiliarizationWindow

    app = QtWidgets.QApplication(sys.argv)
    app.setStyle('Fusion')
    window = FamiliarizationWindow()
    window.show()
    app.exec_()

    return window.selection


## Classification 
def StartClassification(): 
    from GUI_start_classification import StartClassificationWindow

    app = QtWidgets.QApplication(sys.argv)
    app.setStyle('Fusion')
    window = StartClassificationWindow()
    window.show()
    app.exec_()


## Classification 
def OpenGuiClassification(stimulation): 
    from GUI_classification import ClassificationWindow

    app = QtWidgets.QApplication(sys.argv)
    app.setStyle('Fusion')
    window = ClassificationWindow(stimulation)
    window.show()
    app.exec_()

    return window.ans_list


## Set experimental parametets
def OpenGuiParameters(current_parameters):
    from GUI_experiment_parameters import ExperimentParameters

    app = QtWidgets.QApplication(sys.argv)
    app.setStyle('Fusion')
    window = ExperimentParameters(current_parameters)
    window.show()
    app.exec_()
    
    return window.new_parameters


## Start Recording 
def OpenGuiRecording(text): 
    from GUI_recording import RecordingWindow

    app = QtWidgets.QApplication(sys.argv)
    app.setStyle('Fusion')
    window = RecordingWindow(text)
    window.show()
    app.exec_()


## Interfaces per experiment
def OpenGuiInterfaces(path_results_xlsx_exp, path_safety_txt_experiment, parameters):
    from GUI_interfaces import InterfacesWindow

    app = QtWidgets.QApplication(sys.argv)
    app.setStyle('Fusion')
    window = InterfacesWindow(path_results_xlsx_exp, path_safety_txt_experiment, parameters)
    window.setWindowTitle("MessageWindow")
    window.setStyleSheet("BackGround: white")
    window.resize(2000,1500)
    window.showFullScreen()
    sys.exit(app.exec())

