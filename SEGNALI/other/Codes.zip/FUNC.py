import pandas as pd
import numpy as np 
import os
import subprocess


## Clean Terminal
def CleanTerminal():
    if os.name == 'nt':
        _ = os.system('cls')


## Close any prompts
def ClosePrompts(name_terminal_csharp):
    # Getting the list of running processes
    running_processes = subprocess.Popen('tasklist', stdout=subprocess.PIPE, shell=True).communicate()[0]
    running_processes = running_processes.decode('utf-8')

    # Checking for 'cmd.exe' processes and closing them
    for line in running_processes.split('\n'):
        terminal_names = [name_terminal_csharp, 'cmd.exe', 'WindowsTerminal.exe', 'OpenConsole.exe' ]

        for terminal in terminal_names:
            if terminal in line:
                pid = int(line.split()[1])
                os.system(f"taskkill /F /PID {pid}")
                print(f"Closed Command Prompt with PID: {pid}")


## Run in new prompt 
def RunNewPrompt(name_exe):
    import subprocess
    try:
        process = subprocess.Popen(['start', 'cmd', '/k', name_exe], 
                                   shell=True, )
            
    except Exception as e:
        print(f"An error occurred: {e}")
    
    return process


## Define numbers of combinations btw stimulation parameters
def DefineNCombs(list): 
    ncomb = 1
    for element in list:
        ncomb = ncomb * len(element) 
    return ncomb


## Create all possible combinations btw stimulation parameters
def CreateAllCombinations(name, list, ncomb):  

    # 0 Duration
    # 1 Force
    # 2 Temperature
    # 3 Frequency
    df = pd.DataFrame()
    stim_combs = np.zeros(ncomb)
    column = len(list)-1
    reps = 0
   
    while column >= 0 :    
        array = list[column]  

        if column+1 >= len(list): 
            reps = reps + 1; 
        else:
            next_column = column+1
            reps = reps*len(list[next_column])
        
        row = 0
        while row < ncomb: 
            
            row_par = 0
            while row_par < len(array): 
                
                r = 0
                while r < reps:
                    stim_combs[row] = array[row_par]
                    r += 1
                    row += 1
                row_par += 1

        df[name[column]] = pd.DataFrame(stim_combs)     
        column -= 1
    
    df = df[df.columns[::-1]]
    
    return df


# SetActuationString
def SetActuationPoints(hand, finger): 
    strings = ['','']

    if hand == 1:
        strings[0] = 'LEFT'
    else: 
        strings[0] = 'RIGHT'

    if finger == 0:
        strings[1] = 'INDEX'
    elif finger == 1: 
        strings[1] = 'MIDDLE'
    else: 
        strings[1] = 'RING'
    
    return strings


# Create Command string
def GenerateCommand(command, save_folder):
    filename_par = f'{save_folder}\_xlsx_parameters.xlsx'
    df = pd.read_excel(filename_par)
   
    par_vibration_no = df.loc[df['Data'] == 'Min'].iloc[0,df.shape[1]-3:df.shape[1]].tolist()
    par_vibration_stim = df.loc[df['Data'] == 'Max'].iloc[0,df.shape[1]-3:df.shape[1]].tolist()

    command_list = []
    if  command[-1] == 1:
        cmd = [command[0],  
               command[1], command[2], command[3], 
               command[4], 
               int(par_vibration_no[0]), par_vibration_no[1], int(par_vibration_no[2])]
        command_list += [cmd]

    else: 
        dur_trial = command[0]
        period = 1/command[-1]
        dur_stim = 0.07
        dur_basal = round(period-dur_stim, 3)
        tot_reps = round(dur_trial/period) 

        cmd_yes = [dur_stim,
                   command[1], command[2], command[3], 
                   command[4],
                   int(par_vibration_stim[0]), par_vibration_stim[1], int(par_vibration_stim[2])]
        
        cmd_no =  [dur_basal,
                   command[1], command[2], command[3], 
                   command[4],                   
                   int(par_vibration_no[0]), par_vibration_no[1], int(par_vibration_no[2])]
        
        for _ in range(tot_reps):
            command_list = command_list + [cmd_no]
            command_list = command_list + [cmd_yes]
 
    string_command = Command2String(command_list)
    return string_command


# Create Command string
# Create Command string
def Command2String(list_of_list):  
    
    str_command = ""
    ind_list = 0

    for list in list_of_list:
        str_command = str_command + str(list[0])
        for ind_2 in range(len(list)-1):
            element = list[ind_2+1]
            str_command = str_command + ", " + str(element) 
        if (ind_list+1) != len(list_of_list):
            str_command = str_command +  " new "  

        ind_list += 1

    return str_command


## Input basal force dataframe  
def ImportBasalForce(column_to_update, to_replace, force_value):

    for i in range(len(column_to_update)):
        if column_to_update[i] == to_replace:
            column_to_update[i] = force_value

    return column_to_update

# Create data frame without cues and pauses
def StimDataframe(df_comb, df_stim, radn_sequence):
    r = 0
    for row in radn_sequence:
        df_stim.loc[r,:] = df_comb.iloc[row,:].to_list()
        r += 1 

    return df_stim


# Check answers
def CheckAnwers(df_answers, N): 
    c = df_answers.loc[(df_answers == '')].count()
    return [f'{c}/{N}' , c/N]


def CalculatePerc(df_answers, ncomb): 
    
    n_comb_error, failed_comb   = 0, []
    df_answers['Check Combination'] = float('nan')

    for n in range(ncomb): 
        if ( df_answers['Force Errors'].iloc[n] == 'ERROR' or df_answers['Vibration Errors'].iloc[n] == 'ERROR'):
            df_answers['Check Combination'].iloc[n] = 'WRONG'
            failed_comb = failed_comb + [df_answers['N. Comb'].iloc[n]]
            n_comb_error += 1
        elif ( df_answers['Force Errors'].iloc[n] == '' or df_answers['Vibration Errors'].iloc[n] == ''): 
            df_answers['Check Combination'].iloc[n]= ''
    
    return [ f'{ncomb-n_comb_error}/{ncomb}', (ncomb-n_comb_error)/ncomb ]
