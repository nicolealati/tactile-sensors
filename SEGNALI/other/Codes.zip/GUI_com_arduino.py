from PyQt5 import QtGui, QtCore
from PyQt5.QtWidgets import QWidget, QLabel, QLineEdit, QHBoxLayout, QVBoxLayout, QPushButton, QGroupBox, QRadioButton

class ComArduino(QWidget):
    def __init__(self):
        super().__init__()
        self.WindowSetup()

    def WindowSetup(self):
        self.setWindowTitle('Arduino Port GUI')
        self.setGeometry(700, 400, 400, 400)

        font = QtGui.QFont()
        font.setPointSize(11)

        x = 30 
        y_button_1, y_button_2, = 30, 60
        width, height  = 260, 40



        self.com_label = QLabel('COM')
        self.com_label.setFont(font)
        self.com_edit = QLineEdit(self)
        self.com_edit.setFont(font)

        self.submit_button = QPushButton('SUBMIT', self)
        self.submit_button.setFont(font)
        self.submit_button.setStyleSheet('background-color: lightgray;')
        self.submit_button.clicked.connect(self.SubmitData)

        self.request_label = QLabel("Insert COM port number:")
        self.request_label.setFont(font)

        ## TRIGGER Groupbox
        self.groupbox_trigger = QGroupBox("Send trigger")
        self.groupbox_trigger.setFont(font)

        self.trigger_true_button = QRadioButton(self.groupbox_trigger)
        self.trigger_true_button.setGeometry(QtCore.QRect(x, y_button_1, width, height))
        self.trigger_true_button.setText(" True")
        self.trigger_true_button.setFont(font)

        self.trigger_false_button = QRadioButton(self.groupbox_trigger)
        self.trigger_false_button.setGeometry(QtCore.QRect(x, y_button_2, width, height))
        self.trigger_false_button.setText(" False")
        self.trigger_false_button.setFont(font)

        ## TRIGGER Groupbox
        self.groupbox_diver = QGroupBox("Use TouchDiver")
        self.groupbox_diver.setFont(font)

        self.diver_true_button = QRadioButton(self.groupbox_diver)
        self.diver_true_button.setGeometry(QtCore.QRect(x, y_button_1, width, height))
        self.diver_true_button.setText(" True")
        self.diver_true_button.setFont(font)

        self.diver_false_button = QRadioButton(self.groupbox_diver)
        self.diver_false_button.setGeometry(QtCore.QRect(x, y_button_2, width, height))
        self.diver_false_button.setText(" False")
        self.diver_false_button.setFont(font)

        self.empty_label = QLabel("")
        self.empty_label.setFont(font)

        layout_com = QHBoxLayout()
        layout_com.addWidget(self.com_label)
        layout_com.addWidget(self.com_edit)

        layout_bool = QHBoxLayout()
        layout_bool.addWidget(self.groupbox_diver)
        layout_bool.addWidget(self.groupbox_trigger)

        layout_vertical = QVBoxLayout()
        # layout_vertical.addWidget(self.empty_label)
        # layout_vertical.addLayout(layout_bool)
        layout_vertical.addWidget(self.request_label)
        layout_vertical.addLayout(layout_com)
        layout_vertical.addWidget(self.empty_label)
        layout_vertical.addWidget(self.submit_button)

        self.setLayout(layout_vertical)

    def SubmitData(self):
        self.submit_button.setEnabled(False)
        
        self.COMport = f"{self.com_edit.text()}"
        self.diver = "false"
        self.trigger = "false"

        
        for radio_botton in self.groupbox_diver.findChildren(QRadioButton): 
            if radio_botton.isChecked(): 
                self.diver = radio_botton.text()
                break
        if self.diver == None or self.diver == " False":
            self.diver = "false"
        elif  self.diver == " True": 
            self.diver = "true"
        

        for radio_botton in self.groupbox_trigger.findChildren(QRadioButton): 
            if radio_botton.isChecked(): 
                self.trigger = radio_botton.text()
                break
        if self.trigger == None or self.trigger == " False":
            self.trigger = "false"
        elif  self.trigger == " True":
            self.trigger = "true"
        
        self.ans = [self.COMport, self.diver, self.trigger]

        self.close()

        return self.ans

