﻿using System;
using System.Collections;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using WeArt.Core;

namespace PRE_Calib_csharp
{
    public class PRE_Calib_class_HANDLE_STIMULATION
    {
        private string handler;
        private bool loop_flag;
        private string str_print = "(HANDLE_STIMULATION) ";

        // WEART MIDDLEWARE (TCP/IP connection)
        private PRE_Calib_class_TOUCH_DIVER WeArtExpController;
        private HandSideFlags WeArtHandConfig;
        private ActuationPointFlags WeArtFingerConfig;
        private static PRE_Calib_class_HANDLE_STIMULATION expController = new();

        private float Duration;
        private float[]? Force;
        private float Temperature;
        private float Type;
        private float Velocity;
        private float Volume;


        public PRE_Calib_class_HANDLE_STIMULATION()
        {
            handler = string.Empty;
        }

        internal void StimulationHandle(ConcurrentQueue<List<string>> storage_queue, bool touchdiver_flag)
        {
            Console.WriteLine($"\n{str_print}StimulationHandle");

            bool loop_flag = true;
            while (storage_queue.Count != 0 || loop_flag)
            {
                // Create list for list from retrieved queue 
                List<string> retrieved_list;

                // Deque list from queue
                bool retrieving_success = storage_queue.TryDequeue(out retrieved_list);

                // [0] - TRIGGERS 
                //       50 - start
                //       51 - stop
                //       62 - break
                //       70 - stimulation
                //       80 - stimulation + classification 

                if (retrieving_success)
                {
                    // Save trigger (index 0 in the list)
                    int trigger = int.Parse(retrieved_list[0]);

                    if (trigger == 50) // Start command
                    {
                        Console.WriteLine($"\n\n{str_print}START - Trigger = {trigger}");

                        // Connect touchdiver
                        if (touchdiver_flag)
                        {
                            expController.WeArtExpController = new PRE_Calib_class_TOUCH_DIVER();
                        }

                    }


                    else if (trigger == 51) // STOP command
                    {
                        Console.WriteLine($"\n\n{str_print}STOP - Trigger = {trigger}");

                        // Close touchdiver
                        if (touchdiver_flag)
                        {
                            expController.WeArtExpController.CloseWeArtSocket();
                        }

                        // Exit from the while loop
                        loop_flag = false;
                    }


                    else if (trigger == 62) // BREAK command
                    {
                        Console.WriteLine($"\n\n{str_print}BREAK - Trigger = {trigger}");

                        // Split string by "," to obtain parameters
                        string[] splitted_break_stim = retrieved_list[1].Split(",");
                        Console.WriteLine($"{str_print}     Command = {retrieved_list[1]}");

                        // Send stimulation 
                        expController.Duration = 0.1f;
                        float[] f_break = { float.Parse(splitted_break_stim[1]), float.Parse(splitted_break_stim[2]), float.Parse(splitted_break_stim[3]) };
                        expController.Force = f_break;
                        expController.Temperature = float.Parse(splitted_break_stim[4]);
                        expController.Type = float.Parse(splitted_break_stim[5]);
                        expController.Velocity = float.Parse(splitted_break_stim[6]);
                        expController.Volume = float.Parse(splitted_break_stim[7]);
                        SendStimulation(touchdiver_flag, float.Parse(splitted_break_stim[0]));
                    }



                    else  // STIMULATION or STIMULATION + CLASSIFICATION command
                    {
                        string session = retrieved_list[1];
                        string nstim = retrieved_list[2];
                        int ncomb = int.Parse(retrieved_list[3]);
                        int trigger_cue = int.Parse(retrieved_list[5]);
                        string command_cue = retrieved_list[6];
                        int trigger_pause = int.Parse(retrieved_list[7]);
                        string command_pause = retrieved_list[8];
                        string type_trial = (trigger == 70) ? "STIMULATION" : "STIMULATION + CLASSIFICATION";
                        bool class_flag = (trigger == 70) ? false : true;

                        Console.WriteLine($"\n\n{str_print} S{session} n{nstim} - {type_trial}");

                        // STIMULATION
                        // Create secondary queue to store splitted list
                        ConcurrentQueue<List<float>> sec_storage_queue = new();
                        sec_storage_queue = SplitCommand(retrieved_list[4], sec_storage_queue);

                        // STIMULATION command
                        Console.WriteLine($"{str_print}          Stimulation - Combination {ncomb}");

                        Stopwatch watch_stim = new Stopwatch();
                        watch_stim.Start();
                        // Send stimulation
                        while (sec_storage_queue.Count != 0)
                        {
                            List<float> cmd;
                            // Deque list from the queue and save 
                            bool success_dequeue = sec_storage_queue.TryDequeue(out cmd);
                            if (success_dequeue)
                            {
                                Console.WriteLine($"{str_print}                Dequed command  <<{string.Join(",", cmd)}>>");

                                expController.Duration = cmd[0];
                                float[] f_stim = { cmd[1], cmd[2], cmd[3] };
                                expController.Force = f_stim;
                                expController.Temperature = cmd[4];
                                expController.Type = cmd[5];
                                expController.Velocity = cmd[6];
                                expController.Volume = cmd[7];
                                SendStimulation(touchdiver_flag, cmd[0]);

                            }
                        } // END while (sec_storage_queue.Count != 0)
                        watch_stim.Stop();
                        TimeSpan t_stim = watch_stim.Elapsed;
                        string elapsed_time_stim = String.Format("{0:00}:{1:00}", t_stim.Seconds, t_stim.Milliseconds / 10);
                        Console.WriteLine($"Time STIM:  {elapsed_time_stim}");
                    }
                } // END if (retrieving_success)
            } // END while loop

            Console.WriteLine($"{str_print}StimulationHandle done\n");

        }// END StimulationHandle

        static ConcurrentQueue<List<float>> SplitCommand(string str_command, ConcurrentQueue<List<float>> sec_storage_queue)
        {
            // Split retrieved_primary_command string by "new" obtaining an array of strings
            string[] str_sub_commands = str_command.Split("new");
            //foreach (var s in str_sub_commands) {Console.WriteLine($"(HANDLE_STIMULATION)     Splitted: {s}");}

            // Iterate each string element of the string
            foreach (var element in str_sub_commands)
            {
                // Split retrieved_primary_command string by "new" obtaining an array of strings
                string[] splitted_sub_commands = element.Split(",");
                //foreach (var s2 in str_sub_commands) {Console.WriteLine($"(HANDLE_STIMULATION)     Splitted: {s2}");}

                // Create an empty storage list to store sub_commands
                var sub_commands_list = new List<float> { };

                // Add subcommands to list
                sub_commands_list.Add(float.Parse(splitted_sub_commands[0]));   // Duration
                sub_commands_list.Add(float.Parse(splitted_sub_commands[1]));   // Force index finger
                sub_commands_list.Add(float.Parse(splitted_sub_commands[2]));   // Force middle finger
                sub_commands_list.Add(float.Parse(splitted_sub_commands[3]));   // Force ring finger
                sub_commands_list.Add(float.Parse(splitted_sub_commands[4]));   // Temperature
                sub_commands_list.Add(float.Parse(splitted_sub_commands[5]));   // Type
                sub_commands_list.Add(float.Parse(splitted_sub_commands[6]));   // Velocity
                sub_commands_list.Add(float.Parse(splitted_sub_commands[7]));   // Volume

                // Enqueue list into queue
                sec_storage_queue.Enqueue(sub_commands_list);
                //Console.WriteLine($"(HANDLE_STIMULATION)    Enqueued command  <<{string.Join(",", sub_commands_list)}>>");
            }
            return sec_storage_queue;
        }// END SplitCommand

        static void SendGuiMessage(string trigger, StreamWriter writer, NetworkStream stream)
        {
            string str_print = "(HANDLE_STIMULATION_GUI) ";
            // Send message for gui
            writer.WriteLine(trigger);
            writer.Flush();
            Console.WriteLine($"{str_print}Sent message: {trigger}");

            // Wait for the message back
            WaitMessageBack(stream);

        }// END Fucntion

        static void WaitMessageBack(NetworkStream stream)
        {
            string str_print = "(HANDLE_STIMULATION_GUI) ";
            byte[] buffer = new byte[256];
            while (true)
            {
                if (stream.DataAvailable)
                {
                    // Calculate number of received bytes
                    int bytesRead = stream.Read(buffer, 0, buffer.Length);
                    if (bytesRead > 0)
                    {
                        string message_back = Encoding.UTF8.GetString(buffer, 0, bytesRead);
                        Console.WriteLine($"{str_print}Recv message: {message_back}");

                        break;
                    } // END if (bytesRead > 0)
                } // END if (stream.DataAvailable)
            } // END while(true) 
        } // END WaitMessageBack


        static void SendStimulation(bool touchdiver_flag, float dur)
        {
            string str_print = "(HANDLE_STIMULATION_GUI) ";

            if (touchdiver_flag)
            {
                expController.TouchDiverStimulation();
            }
            else
            {
                Console.WriteLine($"{str_print}          Sending stimulation (flag = false)");
            }

            Thread.Sleep((int)(expController.Duration * 1000));
            Thread.Sleep((int)((dur - expController.Duration) * 1000));
        }

        private void TouchDiverStimulation()
        {
            WeArtExpController.SendActuationAsync(
                duration: Duration,
                force: Force,
                temperature: Temperature,
                type: Type,
                velocity: Velocity,
                volume: Volume
                );
        } // END TouchDiverStimulation
    }
}
