from PyQt5 import QtGui
from PyQt5.QtWidgets import QWidget, QLabel, QHBoxLayout, QVBoxLayout, QPushButton

class PcWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.WindowSetup()


    def WindowSetup(self):
        self.setWindowTitle('Pc GUI')
        self.setGeometry(700, 400, 300, 300)

        font = QtGui.QFont()
        font.setPointSize(11)

        self.label = QLabel('Select current pc:')
        self.label.setFont(font)

        self.empty_label = QLabel('  ')
        self.empty_label.setFont(font)

        self.personal_button = QPushButton("\nPersonal\n", self)
        self.personal_button.setFont(font)
        self.personal_button.setStyleSheet('background-color: #f4a460;')
        self.personal_button.clicked.connect(self.PersonalSelection)

        self.alienware_button = QPushButton("\nAlienware\n", self)
        self.alienware_button.setFont(font)
        self.alienware_button.setStyleSheet('background-color: 	#f4a460 ;')
        self.alienware_button.clicked.connect(self.AlienwareSelection)

        layout_buttons = QHBoxLayout()
        layout_buttons.addWidget(self.personal_button)
        layout_buttons.addWidget(self.alienware_button)

        layout = QVBoxLayout()
        layout.addWidget(self.label)
        layout.addLayout(layout_buttons)
        layout.addWidget(self.empty_label)

        self.setLayout(layout)


    def PersonalSelection(self):
        self.personal_button.setEnabled(False)
        self.selection = "personal"
        self.CloseFunction()

    def AlienwareSelection(self):
        self.alienware_button.setEnabled(False)
        self.selection = "alienware"
        self.CloseFunction()

    
    def CloseFunction(self):
        self.close()
        return self.selection


