## Libraries
import pandas as pd
import numpy as np
from datetime import datetime
import time 
import socket
import random 
import shutil
from FUNC import CleanTerminal
from FUNC import RunNewPrompt, ClosePrompts
from FUNC import ImportBasalForce, StimDataframe, GenerateCommand
from FUNC import CheckAnwers, CalculatePerc
from FUNC_GUI import OpenGuiNumbReps, StartClassification, OpenGuiClassification


def Classification(subject_ID, path_subj_folder, filename_prompt_csharp, path_prompt_csharp):
    
    CleanTerminal()
    print("\nCLASSIFICATION TASK\n") 



    ###### FILENAMES AND SHEETS ####################################################
    ## Filenames
    filename_xlsx_parameters = "_xlsx_parameters.xlsx"
    filename_xlsx_combinations = "_xlsx_combinations.xlsx"                       
    filename_xlsx_force = "_xlsx_thimble_basal.xlsx"
    filename_xlsx_familiarization = "_xlsx_familiarization.xlsx"           
    filename_xlsx_classification = "_xlsx_pre_classification_template.xlsx"
    filename_xlsx_triggers = "_xlsx_triggers_dict.xlsx"

    ## Sheets
    sheet_force = "Basal Forces"
    sheet_stim = 'Classification Sequence'         
    sheet_answ = 'Answers'                      
    sheet_class = 'Classification'
    sheet_time = "Timetable"  

    
    ###### INITIALIZATIONS ####################################################
    ## N. Repetition of the sequence
    n_reps = OpenGuiNumbReps()



    ###### FORCE DATA FRAME ####################################################
    ## Upload basal force file as a dataframe
    path_xlsx_forces = f'{path_subj_folder}\{filename_xlsx_force}'
    df_forces = pd.read_excel(path_xlsx_forces, sheet_name=sheet_force)
    df_forces = df_forces.iloc[2:4, :]
    
    print(f'\nBasal forces dataframe: \n\n{df_forces}\n')

    ## Take from the dataframe max and min force values for each finger
    force_min_index = df_forces.iloc[0, 1].tolist()
    force_min_middle = df_forces.iloc[0, 2].tolist()
    force_min_ring = df_forces.iloc[0, 3].tolist()
    force_max_index = df_forces.iloc[1, 1].tolist()
    force_max_middle = df_forces.iloc[1, 2].tolist()
    force_max_ring = df_forces.iloc[1, 3].tolist()



    ###### COMBINATIONS DATA FRAME ####################################################
    ## Upload combination file as a dataframe
    path_xlsx_combinations = f'{path_subj_folder}\{filename_xlsx_combinations}'
    df_combinations = pd.read_excel(path_xlsx_combinations)

    ##Change 'Basal' with corresponding force value
    force_to_replace = 'Basal Min'
    df_combinations['Force (index)'] = ImportBasalForce(df_combinations['Force (index)'].to_list(), force_to_replace, force_min_index)
    df_combinations['Force (middle)'] = ImportBasalForce(df_combinations['Force (middle)'].to_list(), force_to_replace, force_min_middle)
    df_combinations['Force (ring)'] = ImportBasalForce(df_combinations['Force (ring)'].to_list(), force_to_replace, force_min_ring)
    force_to_replace = 'Basal Max'
    df_combinations['Force (index)'] = ImportBasalForce(df_combinations['Force (index)'].to_list(), str(force_to_replace), force_max_index)
    df_combinations['Force (middle)'] = ImportBasalForce(df_combinations['Force (middle)'].to_list(), str(force_to_replace), force_max_middle)
    df_combinations['Force (ring)'] = ImportBasalForce(df_combinations['Force (ring)'].to_list(), str(force_to_replace), force_max_ring)
    
    print(f'\nUPDATE combination dataframe: \n{df_combinations}\n\n')



    ###### FAMILIARIZATION DATA FRAME ####################################################
    ## Upload familiarization file as a dataframe
    filepath_fam = f'{path_subj_folder}\{filename_xlsx_familiarization}'
    df_familiarization = pd.read_excel(filepath_fam)
    print(f'\nFamiliarization dataframe: \n\n{df_familiarization}\n\n')

    ## Extract cue command and create string
    cmd_cue = df_familiarization.loc[df_familiarization['Stimulation type'] == 'Cue'].iloc[0, 2:df_familiarization.shape[1]].tolist()
    cmd_str_cue = GenerateCommand(cmd_cue, path_subj_folder)
    dur_cue = cmd_cue[0]

    ## Extract pause command and create string
    cmd_pause = df_familiarization.loc[df_familiarization['Stimulation type'] == 'Pause'].iloc[0, 2:df_familiarization.shape[1]].tolist()
    cmd_str_pause = GenerateCommand(cmd_pause, path_subj_folder)
    dur_pause = cmd_pause[0]

    ## Extract duration stimulus
    dur_stim = df_familiarization.loc[df_familiarization['Stimulation type'] == 'Force Min'].iloc[0, 2].tolist()




    ###### TRIGGER DATA FRAME ####################################################
    ## Extract trigger dictionary from txt file
    df_trigger = pd.DataFrame()
    df_trigger = pd.read_excel(f"{path_subj_folder}\{filename_xlsx_triggers}")

    ## Extract triggers 
    trigger_start = df_trigger['Trigger'].loc[df_trigger['Trigger name'] == 'Start Experiment'].iloc[0].tolist()
    trigger_stop = df_trigger['Trigger'].loc[df_trigger['Trigger name'] == 'Stop Experiment'].iloc[0].tolist()
    trigger_cue = df_trigger['Trigger'].loc[df_trigger['Trigger name'] == 'Cue'].iloc[0].tolist()
    trigger_pause = df_trigger['Trigger'].loc[df_trigger['Trigger name'] == 'Pause'].iloc[0].tolist()
    trigger_stim = df_trigger['Trigger'].loc[df_trigger['Trigger name'] == 'Stimulation'].iloc[0].tolist()



    ###### TRIGGER DATA FRAME ####################################################
    ## Upload basal force file as a dataframe
    path_xlsx_parameters = f'{path_subj_folder}\{filename_xlsx_parameters}'
    df_parameters = pd.read_excel(path_xlsx_parameters)



    ###### COMBINATIONS AND RANDOM SEQUENCE  ####################################################
    ## Calculate number of combinations
    ncomb = df_combinations.shape[0]
    n_stim = ncomb*n_reps
    print(f'N stimulations: {n_stim}\n\n')

    ## Create random sequence for the stimualtion        
    radn_sequence = np.empty( (0), dtype=int)
    print(f'Random sequence (increase by 1 for corresponsing N. Comb): ')
    for _ in range(n_reps):
        sequence = np.linspace(0, ncomb-1, ncomb, dtype=int)        
        random.shuffle(sequence)
        print(f' {sequence}')
        radn_sequence = np.concatenate((radn_sequence, sequence), axis=0, dtype=int)
    
    ## Create stimulation dataframes
    df_stimulations = pd.DataFrame(columns=['N. Comb', 'Duration','Force (index)','Force (middle)','Force (ring)', 'Temperature','Frequency'])
    df_stimulations = StimDataframe(df_combinations, df_stimulations, radn_sequence)

    df_stimulations['N. Comb'] = df_stimulations['N. Comb']. astype(int)
    df_stimulations['Frequency'] = df_stimulations['Frequency']. astype(int)

    print(f'\n\nStimulation dataframe: \n{df_stimulations}\n')



    ###### CLASSIFICATION SESSION  ####################################################
    try: 
        ClosePrompts(filename_prompt_csharp)
        RunNewPrompt(path_prompt_csharp)
        


        ###### SOCKET ####################################################
        ## Create socket with csharp file
        host, port = "127.0.0.1", 5555
        aClientSocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        aClientSocket.connect((host, port))



        ###### GUI START ####################################################
        StartClassification()
        


        ###### TIMESTAMP ####################################################
        start_calibration = datetime.now()
        date = f'{str(start_calibration.year)}_{str(start_calibration.month)}_{str(start_calibration.day)}'
        time_test =f'{start_calibration.strftime("%Hh_%Mm_%Ss")}'
    

        
        ###### INIZIALIZATIONS ####################################################
        comb_name = []
        prov_force, prov_vibr = [], []
        answers = []
        ind_stim = 0    

        duration_sleep = dur_cue + dur_stim + dur_pause


        ###### START CLASSIFICATION ####################################################
        while True:  

            ## Send START command to connect the middleware 
            cmd_str_start = f"cmd : {trigger_start} : end"
            print(f'\nSent command <<{cmd_str_start}>>')
            aClientSocket.send(cmd_str_start.encode("utf-8"))

            while ind_stim < df_stimulations.shape[0]:     

                ## Save combination name
                comb_n_ = df_stimulations['N. Comb'].iloc[ind_stim]
                print(f'\n\n------------------------> Stimulation n. {ind_stim+1}/{n_stim}  - Comb_n_{int(comb_n_)}\n')

                ## Prepate and send stimulatio command
                cmd_stim = df_stimulations.iloc[ind_stim,1:7]
                cmd_str_stim = GenerateCommand(cmd_stim, path_subj_folder)
                print(cmd_stim)
                command = f"cmd : 0 : 0 : {trigger_stim} : {trigger_stim} : {cmd_str_stim} : {trigger_cue} : {cmd_str_cue} : {trigger_pause} : {cmd_str_pause} : end "
                aClientSocket.send(command.encode("utf-8"))

                ## Create matrices  
                comb_name = comb_name + [comb_n_]
                prov_force = prov_force + [df_stimulations['Force (index)'].iloc[ind_stim]]     
                prov_vibr = prov_vibr + [df_stimulations['Frequency'].iloc[ind_stim]]     

                ## Open GUI and wait 
                answers = answers + [OpenGuiClassification(f"\nStimulation n. {ind_stim+1}/{n_stim}\n")]                                  
              
                ## Set index of the next stimulation
                ind_stim += 1

            break

        end_time = datetime.now()  
        

    finally:
        ## Send STOP command to disconnect the middleware
        cmd_str_stop = f"cmd: {trigger_stop} : end"
        print(f'\nSent command <<{cmd_str_stop}>>')
        aClientSocket.send(cmd_str_stop.encode("utf-8"))
        
        
        ###### TIMESTAMP ####################################################
        ## Count time elapsed
        time_difference = end_time - start_calibration
        time_elapsed_min = int(time_difference.total_seconds() // 60)
        time_elapsed_sec = int(time_difference.total_seconds() % 60)

        print(f'Time elapsed: {time_elapsed_min}m : {time_elapsed_sec}s')

        ## Save into data frame
        df_time = pd.DataFrame()
        df_time['Data'] = ['Date', 'Test Time', 'Elapsed Time']
        df_time['Time'] = [date, time_test, f'{time_elapsed_min}m : {time_elapsed_sec}s']

       
        ###### ANSWERS DATA FRAME  ####################################################
        ## Separate answers of the different stimuli
        perc_force, perc_vibr = [],[]
        for line in range(len(answers)):
            perc_force = perc_force + [answers[line][0]]
            perc_vibr = perc_vibr + [answers[line][1]]

        print(f'Answers: \n{answers}\n')
        print(f'Force answers: \n{perc_force}')
        print(f'Vibration answers: \n{perc_vibr}')

        ## Create answers dataframe
        df_answers= pd.DataFrame()
        df_answers['N. Comb']= comb_name

        ## Force answers
        df_answers['Prov. Force'], df_answers['Perc. Force'] = prov_force, perc_force
        df_answers ['Force Errors'] = df_answers.loc[:,'Perc. Force']
        ## Replace float with string for comparison with provided answers
        df_answers['Prov. Force'] = ImportBasalForce(df_answers['Prov. Force'].to_list(), force_min_index, ' min')
        df_answers['Prov. Force'] = ImportBasalForce(df_answers['Prov. Force'].to_list(), force_max_index, ' max')
        ## Check answers 
        df_answers['Force Errors'].iloc[ df_answers.index[df_answers['Perc. Force'] == df_answers['Prov. Force']].tolist()] = ''
        df_answers['Force Errors'].iloc[df_answers.index[df_answers['Perc. Force'] != df_answers['Prov. Force']].tolist()] = 'ERROR'

        ## Vibration answers
        df_answers['Prov. Vibration'], df_answers['Perc. Vibration'] = prov_vibr, perc_vibr
        df_answers['Vibration Errors'] = df_answers.loc[:,'Perc. Vibration']
        ## Replace float with string for comparison with provided answers
        freq_constant = df_parameters['Frequency'].loc[df_parameters['Data'] == 'Min'].astype(int).to_list()[0]
        freq_low = df_parameters['Frequency'].loc[df_parameters['Data'] == 'Low'].astype(int).to_list()[0]
        freq_high = df_parameters['Frequency'].loc[df_parameters['Data'] == 'Max'].astype(int).to_list()[0]
        df_answers['Prov. Vibration'] = df_answers['Prov. Vibration'].replace(freq_constant, ' without vibr')
        df_answers['Prov. Vibration'] = df_answers['Prov. Vibration'].replace(freq_low, ' low freq')
        df_answers['Prov. Vibration'] = df_answers['Prov. Vibration'].replace(freq_high, ' high freq')
        ## Check answers 
        df_answers['Vibration Errors'].iloc[ df_answers.index[df_answers['Perc. Vibration'] == df_answers['Prov. Vibration']].tolist()] = ''
        df_answers['Vibration Errors'].iloc[df_answers.index[df_answers['Perc. Vibration'] != df_answers['Prov. Vibration']].tolist()] = 'ERROR'



        ###### CLASSIFICATION DATA FRAME  ####################################################
        ## Calculate classification metrics 
        df_classification = pd.DataFrame()   
        df_classification['Force'] = CheckAnwers(df_answers['Force Errors'], n_stim)
        df_classification['Vibration'] = CheckAnwers(df_answers['Vibration Errors'], n_stim)
        df_classification['Combinations'] = CalculatePerc(df_answers, n_stim)
        df_classification[''] = ['N. Correct answers', 'Correct answers [%]' ]    

        ## Dataframes organization
        df_combinations = df_combinations.set_index('N. Comb')

        cue_code = df_parameters['Code'].loc[df_parameters['Data'] == 'Cue'].astype(int).to_list()[0]
        pause_code = df_parameters['Code'].loc[df_parameters['Data'] == 'Pause'].astype(int).to_list()[0]
        df_stimulations['N. Comb'] = df_stimulations['N. Comb'].replace(cue_code, 'Cue')
        df_stimulations['N. Comb'] = df_stimulations['N. Comb'].replace(pause_code, 'Pause')
        df_stimulations = df_stimulations.set_index('N. Comb')
        
        df_answers = df_answers.sort_values('N. Comb', ascending = True )
        df_answers = df_answers.set_index('N. Comb')

        df_classification = df_classification.set_index('')
        

        ###### SAVE DATA FRAMES  ####################################################
        ## Upload of the parameters as a dataframe
        old_filepath_class = f'{path_subj_folder}\{filename_xlsx_classification}'
        new_filename_xlsx_classification = f"{subject_ID}_pre_classification_{date}_{time_test}.xlsx"
        new_filepath_experiment = f'{path_subj_folder}\{new_filename_xlsx_classification}'   
        shutil.copy2(old_filepath_class, new_filepath_experiment)

        with pd.ExcelWriter(new_filepath_experiment, mode = 'a', engine='openpyxl', if_sheet_exists='overlay') as workbook:
            df_stimulations.to_excel(workbook, sheet_name = sheet_stim, index=True)
            df_answers.to_excel(workbook, sheet_name = sheet_answ, index=True)
            df_classification.to_excel(workbook, sheet_name = sheet_class, index=True)
            df_time.to_excel(workbook, sheet_name = sheet_time, index=False)
        

        
        print("\n\nClassification DONE")



