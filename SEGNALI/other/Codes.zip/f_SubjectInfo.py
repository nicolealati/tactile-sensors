## Libraries
import pandas as pd
from FUNC import CleanTerminal
from FUNC_GUI import OpenGuiSubjectInfo


def SubjectInfo(subject_ID, subj_folder_name):

    CleanTerminal()
    print("\nCREATE SUBJECT GENERAL INFORMATION FILE\n")



    ###### SUBJECT'S DATA  ####################################################
    filename_subj_data = f"_txt_{subject_ID}_data.txt"

    data = OpenGuiSubjectInfo()
    name = data[0]
    surname = data[1]
    gender = data[2]
    date_birth = data[3]
    date_experiment = data[4]

    ## Create dataframe for subject's data
    df_data = pd.DataFrame()
    df_data['   '] = ['Name', 'Surname' , 'Subject_ID', 'Gender', 'Date of birth','Date experiment']             
    df_data['General Info'] = [name, surname, subject_ID, gender, date_birth, date_experiment] 
    df_data = df_data.set_index('   ')
    print(f'\nSubject data dataframe: \n\n{df_data}')
    


    ###### SAVE DATA FRAME ####################################################
    ## Upload of the parameters as a dataframe 
    save_filepath = f'{subj_folder_name}\{filename_subj_data}'
    with open(save_filepath, mode='w') as file_object:
        print(df_data, file=file_object)



    print("\n\nCreate data subject file DONE")

