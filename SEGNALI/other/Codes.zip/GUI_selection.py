from PyQt5 import QtGui
from PyQt5.QtWidgets import QWidget, QLabel, QVBoxLayout, QPushButton

class SelectionWindow(QWidget):
    def __init__(self, flag_list):
        super().__init__()
        self.flag_list = flag_list
        self.WindowSetup()


    def WindowSetup(self):
        self.setWindowTitle('Selection GUI')
        self.setGeometry(700, 400, 300, 300)

        font = QtGui.QFont()
        font.setPointSize(11)

        self.label = QLabel('Select an operation:')
        self.label.setFont(font)

        self.empty_label = QLabel('  ')
        self.empty_label.setFont(font)

        self.label_subject = QLabel("\nSUBJECT")
        self.label_subject.setFont(font)

        self.label_calibration = QLabel("\nCALIBRATION")
        self.label_calibration.setFont(font)

        self.label_familiarization = QLabel("\nFAMILIARIZATION")
        self.label_familiarization.setFont(font)

        self.label_experiment = QLabel("\nEXPERIMENT")
        self.label_experiment.setFont(font)

        self.insert_info_button = QPushButton("Subject's Data", self)
        self.insert_info_button.setFont(font)
        self.insert_info_button.setStyleSheet('background-color: #f0e68c;')
        self.insert_info_button.setEnabled(self.flag_list[0])
        self.insert_info_button.clicked.connect(self.DataSelection)
            
        self.insert_thimble_button = QPushButton("Thimbles", self)
        self.insert_thimble_button.setFont(font)
        self.insert_thimble_button.setStyleSheet('background-color: #f08080;')
        self.insert_thimble_button.setEnabled(self.flag_list[1])
        self.insert_thimble_button.clicked.connect(self.ThimblesSelection)

        self.calibration_button = QPushButton("Force Calibration", self)
        self.calibration_button.setFont(font)
        self.calibration_button.setStyleSheet('background-color: #f08080;')
        self.calibration_button.setEnabled(self.flag_list[2])
        self.calibration_button.clicked.connect(self.CalibrationSelection)

        self.familiarization_button = QPushButton("Individual Stim.", self)
        self.familiarization_button.setFont(font)
        self.familiarization_button.setStyleSheet('background-color: #90ee90;')
        self.familiarization_button.setEnabled(self.flag_list[3])
        self.familiarization_button.clicked.connect(self.FamiliarizationSelection)

        self.classification_button = QPushButton("Combined Stim + Classification", self)
        self.classification_button.setFont(font)
        self.classification_button.setStyleSheet('background-color:#90ee90;')
        self.classification_button.setEnabled(self.flag_list[4])
        self.classification_button.clicked.connect(self.ClassificationSelection)

        self.exp_setup_button = QPushButton("Create EXP setup", self)
        self.exp_setup_button.setFont(font)
        self.exp_setup_button.setStyleSheet('background-color: #add8e6 ;')
        self.exp_setup_button.setEnabled(self.flag_list[5])
        self.exp_setup_button.clicked.connect(self.ExpSetupSelection)

        self.exp_button = QPushButton("Experiment", self)
        self.exp_button.setFont(font)
        self.exp_button.setStyleSheet('background-color: #add8e6 ;')
        self.exp_button.setEnabled(self.flag_list[6])
        self.exp_button.clicked.connect(self.ExpSelection)

        self.close_button = QPushButton("Close window", self)
        self.close_button.setFont(font)
        self.close_button.setStyleSheet('background-color: lightgrey;')
        self.close_button.clicked.connect(self.CloseWindowSelection)

        layout = QVBoxLayout()
        layout.addWidget(self.label)
        layout.addWidget(self.empty_label)
        layout.addWidget(self.label_subject)
        layout.addWidget(self.insert_info_button)
        layout.addWidget(self.label_calibration)
        layout.addWidget(self.insert_thimble_button)
        layout.addWidget(self.calibration_button)
        layout.addWidget(self.label_familiarization)
        layout.addWidget(self.familiarization_button)
        layout.addWidget(self.classification_button)
        layout.addWidget(self.label_experiment)
        layout.addWidget(self.exp_setup_button)
        layout.addWidget(self.exp_button)
        layout.addWidget(self.empty_label)
        layout.addWidget(self.empty_label)
        layout.addWidget(self.close_button)
        
        self.setLayout(layout)

    def DataSelection(self):
        self.insert_info_button.setEnabled(False)
        self.selection = 1
        self.CloseFunction()

    def ThimblesSelection(self):
        self.insert_thimble_button.setEnabled(False)
        self.selection = 2
        self.CloseFunction()
    
    def CalibrationSelection(self):
        self.calibration_button.setEnabled(False)
        self.selection = 3
        self.CloseFunction()
    
    def FamiliarizationSelection(self):
        self.familiarization_button.setEnabled(False)
        self.selection = 4
        self.CloseFunction()
    
    def ClassificationSelection(self):
        self.classification_button.setEnabled(False)
        self.selection = 5
        self.CloseFunction()

    def ExpSetupSelection(self):
        self.exp_setup_button.setEnabled(False)
        self.selection = 6
        self.CloseFunction()

    def ExpSelection(self):
        self.exp_button.setEnabled(False)
        self.selection = 7
        self.CloseFunction()

    def CloseWindowSelection(self):
        self.close_button.setEnabled(False)
        self.selection = 0
        self.CloseFunction()
        
 
    
    def CloseFunction(self):
        self.close()
        return self.selection
