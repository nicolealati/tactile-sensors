# Libraries 
import pandas as pd

def ExpClassification(new_path_xlsx_experiment):

    ###### SHEETS  ####################################################
    sheet_answers = "Answers"
    sheet_classification = "Classification"


    ###### LOAD ANSWERS  ####################################################

    df_answers = pd.read_excel(new_path_xlsx_experiment, sheet_answers)
    n_stim = df_answers.shape[0]
    

    ###### CLASSIFICATION DATA FRAME  ####################################################
    ## Calculate classification metrics 
    ## Force
    count_force_corrects = 0
    force_errors = df_answers['Force Errors'].to_list()
    for ind in range(len(force_errors)):
        if  force_errors[ind] != "ERROR":
            count_force_corrects += 1
    print(f"\n\nCorrect force = {count_force_corrects}/{n_stim}")

    ## Vibration
    count_vibr_corrects = 0
    vibr_errors = df_answers['Vibration Errors'].to_list()
    for ind in range(len(vibr_errors)):
        if  vibr_errors[ind] != "ERROR":
            count_vibr_corrects += 1
    print(f"Correct freq = {count_vibr_corrects}/{n_stim}\n\n")

    ## Combinations
    count_comb_corrects = n_stim
    for n in range(n_stim): 
        if ( df_answers['Force Errors'].iloc[n] == 'ERROR' or df_answers['Vibration Errors'].iloc[n] == 'ERROR'):
            count_comb_corrects -= 1


    ## Save into data frame        
    df_classification= pd.read_excel(new_path_xlsx_experiment, sheet_classification)
    df_classification = pd.read_excel(new_path_xlsx_experiment, sheet_classification)
    df_classification['Force'] = [f"{count_force_corrects}/{n_stim}",  count_force_corrects/n_stim]
    df_classification['Vibration'] = [f"{count_vibr_corrects}/{n_stim}",  count_vibr_corrects/n_stim]
    df_classification['Combinations'] = [ f'{count_comb_corrects}/{n_stim}', (count_comb_corrects)/n_stim ]

    ## Upload of the parameters as a dataframe
    with pd.ExcelWriter(new_path_xlsx_experiment, mode = 'a', engine='openpyxl', if_sheet_exists='overlay') as workbook:
        df_classification.to_excel(workbook, sheet_classification, index=False)





