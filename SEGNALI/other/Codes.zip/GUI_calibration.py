from PyQt5 import QtGui
from PyQt5.QtWidgets import QWidget, QLabel, QVBoxLayout, QHBoxLayout, QPushButton

class Calibration(QWidget):
    def __init__(self, flag_list, color_list, current_force):
        super().__init__()
        self.flag_list = flag_list
        self.color_list = color_list
        self.current_force = current_force
        
        self.WindowSetup()

    def WindowSetup(self):
        self.setWindowTitle('Calibration GUI')
        self.setGeometry(700, 200, 550, 600)

        font_title = QtGui.QFont()
        font_title.setPointSize(11)
        font_title.setBold(True)

        font = QtGui.QFont()
        font.setPointSize(11)

        self.label_title = QLabel('FORCE CALIBRATION:')
        self.label_title.setFont(font_title)
        
        ## FINGER
        self.label_finger = QLabel('\nSelect a finger:')
        self.label_finger.setFont(font)

        self.empty_label = QLabel("")
        self.empty_label.setFont(font)
        
        self.index_button = QPushButton("INDEX\nfinger", self)
        self.index_button.setFont(font)
        self.index_button.setStyleSheet(f'background-color: {self.color_list[0]}')
        self.index_button.setEnabled(self.flag_list[0])
        self.index_button.clicked.connect(self.IndexSelection)

        self.middle_button = QPushButton("MIDDLE\nfinger", self)
        self.middle_button.setFont(font)
        self.middle_button.setStyleSheet(f'background-color: {self.color_list[1]}')
        self.middle_button.setEnabled(self.flag_list[1])
        self.middle_button.clicked.connect(self.MiddleSelection)

        self.ring_button = QPushButton("RING\nfinger", self)
        self.ring_button.setFont(font)
        self.ring_button.setStyleSheet(f'background-color: {self.color_list[2]}')
        self.ring_button.setEnabled(self.flag_list[2])
        self.ring_button.clicked.connect(self.RingSelection)

        ## FORCE
        self.label_force = QLabel('\nSelect the force to calibrate:')
        self.label_force.setFont(font)

        self.min_button = QPushButton("MIN\nforce", self)
        self.min_button.setFont(font)
        self.min_button.setStyleSheet(f'background-color: {self.color_list[3]}')
        self.min_button.setEnabled(self.flag_list[3])
        self.min_button.clicked.connect(self.MinSelection)

        self.max_button = QPushButton("MAX\nforce", self)
        self.max_button.setFont(font)
        self.max_button.setStyleSheet(f'background-color: {self.color_list[4]}')
        self.max_button.setEnabled(self.flag_list[4])
        self.max_button.clicked.connect(self.MaxSelection)

        self.close_force_button = QPushButton("Change finger", self)
        self.close_force_button.setFont(font)
        self.close_force_button.setStyleSheet(f'background-color: {self.color_list[5]}')
        self.close_force_button.setEnabled(self.flag_list[5])
        self.close_force_button.clicked.connect(self.ChangeFingerSelection)

        ## OPERATION
        self.label_operation = QLabel('\nSelect an operation:')
        self.label_operation.setFont(font)

        self.double_plus_button = QPushButton("+ 0.05", self)
        self.double_plus_button.setFont(font)
        self.double_plus_button.setStyleSheet(f'background-color: {self.color_list[6]}')
        self.double_plus_button.setEnabled(self.flag_list[6])
        self.double_plus_button.clicked.connect(self.DoublePlusSelection)

        self.plus_button = QPushButton("+ 0.01", self)
        self.plus_button.setFont(font)
        self.plus_button.setStyleSheet(f'background-color: {self.color_list[6]}')
        self.plus_button.setEnabled(self.flag_list[6])
        self.plus_button.clicked.connect(self.PlusSelection)
            
        self.minus_button = QPushButton("- 0.01", self)
        self.minus_button.setFont(font)
        self.minus_button.setStyleSheet(f'background-color: {self.color_list[6]}')
        self.minus_button.setEnabled(self.flag_list[6])
        self.minus_button.clicked.connect(self.MinuSelection)

        self.double_minus_button = QPushButton("- 0.05", self)
        self.double_minus_button.setFont(font)
        self.double_minus_button.setStyleSheet(f'background-color: {self.color_list[6]}')
        self.double_minus_button.setEnabled(self.flag_list[6])
        self.double_minus_button.clicked.connect(self.DoubleMinusSelection)

        self.low_freq_button = QPushButton("Low freq.", self)
        self.low_freq_button.setFont(font)
        self.low_freq_button.setStyleSheet(f'background-color: {self.color_list[6]}')
        self.low_freq_button.setEnabled(self.flag_list[6])
        self.low_freq_button.clicked.connect(self.LowFreqSelection)

        self.high_freq_button = QPushButton("High freq.", self)
        self.high_freq_button.setFont(font)
        self.high_freq_button.setStyleSheet(f'background-color: {self.color_list[6]}')
        self.high_freq_button.setEnabled(self.flag_list[6])
        self.high_freq_button.clicked.connect(self.HighFreqSelection)

        self.restore_button = QPushButton("Restore force\nafter vibration", self)
        self.restore_button.setFont(font)
        self.restore_button.setStyleSheet(f'background-color: {self.color_list[6]}')
        self.restore_button.setEnabled(self.flag_list[6])
        self.restore_button.clicked.connect(self.RestoreSelection)

        self.close_operation_button = QPushButton("Change force", self)
        self.close_operation_button.setFont(font)
        self.close_operation_button.setStyleSheet(f'background-color: {self.color_list[7]}')
        self.close_operation_button.setEnabled(self.flag_list[7])
        self.close_operation_button.clicked.connect(self.ChangeForceSelection)

        layout_force_button = QHBoxLayout()
        layout_force_button.addWidget(self.double_plus_button)
        layout_force_button.addWidget(self.plus_button)
        layout_force_button.addWidget(self.minus_button)
        layout_force_button.addWidget(self.double_minus_button)
        
        layout_freq_button = QHBoxLayout()
        layout_freq_button.addWidget(self.low_freq_button)
        layout_freq_button.addWidget(self.high_freq_button)

        ## LABEL FORCE
        self.label_current_force = QLabel("\nCURRENT VALUES")
        self.label_current_force.setFont(font_title)
        
        self.label_current_force_value = QLabel(self.current_force)
        self.label_current_force_value.setFont(font)

        ## CLOSE
        self.close_button = QPushButton("CLOSE", self)
        self.close_button.setFont(font)
        self.close_button.setStyleSheet(f'background-color: {self.color_list[8]}')
        self.close_button.clicked.connect(self.CloseWindowSelection)

        layout_button_fingers = QHBoxLayout()
        layout_button_fingers.addWidget(self.index_button)
        layout_button_fingers.addWidget(self.middle_button)
        layout_button_fingers.addWidget(self.ring_button)

        layout_button_force = QHBoxLayout()
        layout_button_force.addWidget(self.min_button)
        layout_button_force.addWidget(self.max_button)

        vertical_layout = QVBoxLayout()
        vertical_layout.addWidget(self.label_title)

        vertical_layout.addWidget(self.label_finger)
        vertical_layout.addLayout(layout_button_fingers)
        
        vertical_layout.addWidget(self.label_force)
        vertical_layout.addLayout(layout_button_force)
        vertical_layout.addWidget(self.close_force_button)

        vertical_layout.addWidget(self.label_operation)
        vertical_layout.addLayout(layout_force_button)
        vertical_layout.addLayout(layout_freq_button)
        vertical_layout.addWidget(self.restore_button)
        vertical_layout.addWidget(self.close_operation_button)
        vertical_layout.addWidget(self.label_current_force)
        vertical_layout.addWidget(self.label_current_force_value)
        
        vertical_layout.addWidget(self.close_button)

        self.setLayout(vertical_layout)

    def IndexSelection(self):
        self.index_button.setEnabled(False)
        self.selection = "index"
        self.CloseFunction()

    def MiddleSelection(self):
        self.middle_button.setEnabled(False)
        self.selection = "middle"
        self.CloseFunction()
    
    def RingSelection(self):
        self.ring_button.setEnabled(False)
        self.selection = "ring"
        self.CloseFunction()

    def MinSelection(self):
        self.min_button.setEnabled(False)
        self.selection = "min"
        self.CloseFunction()

    def MaxSelection(self):
        self.max_button.setEnabled(False)
        self.selection = "max"
        self.CloseFunction()
    
    def DoublePlusSelection(self):
        self.selection = "+0.05"
        self.CloseFunction()

    def PlusSelection(self):
        self.selection = "+0.01"
        self.CloseFunction()
    
    def MinuSelection(self):
        self.selection = "-0.01"
        self.CloseFunction()
    
    def DoubleMinusSelection(self):
        self.selection = "-0.05"
        self.CloseFunction()

    def LowFreqSelection(self):
        self.selection = "lowfreq"
        self.CloseFunction()

    def HighFreqSelection(self):
        self.selection = "highfreq"
        self.CloseFunction()
    
    def RestoreSelection(self):
        self.selection = "restore"
        self.CloseFunction()
    
    def CloseWindowSelection(self):
        self.close_button.setEnabled(False)
        self.selection = "close"
        self.CloseFunction()

    def ChangeFingerSelection(self):
        self.close_force_button.setEnabled(False)
        self.selection = "changefinger"
        self.CloseFunction()
    
    def ChangeForceSelection(self):
        self.close_operation_button.setEnabled(False)
        self.selection = "changeforce"
        self.CloseFunction()
        
    def CloseFunction(self):
        self.close()
        # return self.selection
