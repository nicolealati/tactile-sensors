import pandas as pd
import numpy as np
import shutil
import random 


from FUNC import CleanTerminal
from FUNC import ImportBasalForce, StimDataframe
from FUNC import GenerateCommand

from FUNC_GUI import OpenGuiParameters


def ExpSetup(subject_ID, path_subj_folder):

    CleanTerminal()  


    ###### INIZIALIZATIONS #######################################################

    # ## LONG
    n_reps = 90              # N. repetitions of the sequence during the experiment  
    n_blocks = 6           # N. blocks during the experiment
    n_class_per_stim = 2     # N. classifications of the same combination for each blocks 
    
    current_parameters = [n_reps, n_blocks, n_class_per_stim] 

    new_parameters = OpenGuiParameters(current_parameters)

    n_reps = new_parameters[0]               # N. repetitions of the sequence during the experiment  
    n_blocks = new_parameters[1]           # N. blocks during the experiment
    n_class_per_stim = new_parameters[2]     # N. classifications of the same combination for each sessi



    ###### FILENAMES AND SHEETS ####################################################
    ## Filenames
    filename_xlsx_combinations = "_xlsx_combinations.xlsx"                       
    filename_xlsx_force = "_xlsx_thimble_basal.xlsx"
    filename_xlsx_familiarization = "_xlsx_familiarization.xlsx"           
    filename_xlsx_experiment = "_xlsx_experiment_template.xlsx"
    filename_xlsx_triggers = "_xlsx_triggers_dict.xlsx"

    ## Sheets' name
    sheet_force = "Basal Forces"
    sheet_stim = 'Experiment Sequence'         



    ###### BASAL FORCES DATA FRAME ####################################################
    ## Upload basal force file as a dataframe
    path_forces = f'{path_subj_folder}\{filename_xlsx_force}'
    df_forces = pd.read_excel(path_forces, sheet_name=sheet_force)
    print(f'\n\nBASAL FORCESs dataframe: \n{df_forces}\n')

    ## Take from the dataframe max and min force values for each finger
    force_min_index = df_forces.iloc[2, 1].tolist()
    force_min_middle = df_forces.iloc[2, 2].tolist()
    force_min_ring = df_forces.iloc[2, 3].tolist()
    force_max_index = df_forces.iloc[3, 1].tolist()
    force_max_middle = df_forces.iloc[3, 2].tolist()
    force_max_ring = df_forces.iloc[3, 3].tolist()



    ###### COMBINATIONS' DATA FRAME ####################################################
    ## Upload combination file as a dataframe
    path_xlsx_combinations = f'{path_subj_folder}\{filename_xlsx_combinations}'
    df_combinations = pd.read_excel(path_xlsx_combinations)

    ## Change 'Basal' with corresponding force value
    force_to_replace = 'Basal Min'
    df_combinations['Force (index)'] = ImportBasalForce(df_combinations['Force (index)'].to_list(), force_to_replace, force_min_index)
    df_combinations['Force (middle)'] = ImportBasalForce(df_combinations['Force (middle)'].to_list(), force_to_replace, force_min_middle)
    df_combinations['Force (ring)'] = ImportBasalForce(df_combinations['Force (ring)'].to_list(), force_to_replace, force_min_ring)
    force_to_replace = 'Basal Max'
    df_combinations['Force (index)'] = ImportBasalForce(df_combinations['Force (index)'].to_list(), str(force_to_replace), force_max_index)
    df_combinations['Force (middle)'] = ImportBasalForce(df_combinations['Force (middle)'].to_list(), str(force_to_replace), force_max_middle)
    df_combinations['Force (ring)'] = ImportBasalForce(df_combinations['Force (ring)'].to_list(), str(force_to_replace), force_max_ring)

    print(f'\n\nCOMBINATIONSs data frame:\n{df_combinations}')


    ###### COMBINATIONS' DATA FRAME ####################################################
    ## Extract trigger dictionary from txt file
    df_trigger = pd.DataFrame()
    df_trigger = pd.read_excel(f"{path_subj_folder}\{filename_xlsx_triggers}")



    ###### EXPERIMENTAL SETUP ####################################################
    n_stim_per_repetition = df_combinations.shape[0]      # N. stimulations for each repetition

    ## Repetitions
    n_stim_per_experiment = n_stim_per_repetition*n_reps            # N. stimulations during the experiment

    print('\n\nREPETITIONS')
    print(f'N. stimulations for each repetition: {n_stim_per_repetition}')
    print(f'N. repetitions during the experiment: {n_reps}')
    print(f'N. stimulations during the experiment: {n_reps} x {n_stim_per_repetition} = {n_stim_per_experiment}')

    ## Blocks
    print('\nSTIMULATION BLOCKS')
    n_reps_per_block = int(n_reps/n_blocks)     # N. repetitions for each sections
    n_stim_per_block = n_reps_per_block*n_stim_per_repetition   # N. stimulations per each block
    print(f'N. blocks during the experiment: {n_blocks}')
    print(f'N. repetitions for each block: {n_reps} / {n_blocks} = {n_reps_per_block}')
    print(f'N. stimulations per each block: {n_reps_per_block} x {n_stim_per_repetition} = {n_stim_per_block}\n')

    ## Define blocks' sheets
    list_sheet_blocks = []
    for s in range(n_blocks):
        list_sheet_blocks.extend([f"Block {s+1}"])
    print(f'Blocks sheets = {list_sheet_blocks}')

    ## Create commands
    cmd_list = []
    for c in range(n_stim_per_repetition): 
        str_cmd = GenerateCommand(df_combinations.iloc[c,1:df_combinations.shape[1]].to_list(), path_subj_folder)
        cmd_list.extend([str_cmd])

    ## Create random sequence for the stimualtion
    random_sequence_entire_experiment = []
    random_sequence_per_blocks = []
    b = 1

    # print(f'\nRandom sequence:')
    for _ in range(n_blocks):
        temporary_random_sequence = []
        for _ in range(n_reps_per_block):   
            sequence = np.linspace(0, n_stim_per_repetition-1, n_stim_per_repetition, dtype=int)        
            random.shuffle(sequence)
            temporary_random_sequence.extend(sequence)
        b = b + 1
        random_sequence_per_blocks.extend([temporary_random_sequence])
        random_sequence_entire_experiment.extend(temporary_random_sequence)

    ## Classification tests 
    print('\nCLASSIFICATION BLOCKS')

    ##  Define indexes of the classification tests (for each block)
    ind_class_per_block =  []
    class_column = []
    for s in range(n_blocks): 
        # Extract combinations's sequence for current block
        list_comb_block = random_sequence_per_blocks[s]

        temporary_ind_list = []
        
        for comb_type in range(n_stim_per_repetition):
            # For each combination, extract corresponding index
            ind = [index for index, value in enumerate(list_comb_block) if value == comb_type]
            # Choose random values from the indexes 
            random_elements = random.sample(ind, n_class_per_stim)
            temporary_ind_list.extend(random_elements)
            # print(f"ind = {ind}, random_elements = {random_elements}")
            temporary_ind_list.sort()

        print(f"Block {s+1} = {temporary_ind_list}")
        ind_class_per_block.extend([temporary_ind_list])

        # Create the classification columns for each block
        classification = [None] * n_stim_per_block
        for c in temporary_ind_list: 
            classification[c] = "Yes"
        class_column.extend([classification])
        


    ###### CREATE BLOCKs DATA FRAMES ####################################################
    list_df_blocks = []
    list_stimulation = np.linspace(1, len(random_sequence_per_blocks[s]), len(random_sequence_per_blocks[s]), dtype = int )

    for s in range(n_blocks): 
        df_blocks = pd.DataFrame(columns=['N. Comb', 'Duration','Force (index)','Force (middle)','Force (ring)', 'Temperature','Frequency'])
        df_blocks = StimDataframe(df_combinations, df_blocks, random_sequence_per_blocks[s])
        df_blocks['N. Comb'] = df_blocks['N. Comb']. astype(int)
        df_blocks['Frequency'] = df_blocks['Frequency']. astype(int)
        df_blocks = pd.concat([pd.Series(class_column[s], name='Class'), df_blocks], axis=1)
        df_blocks = pd.concat([pd.Series(list_stimulation, name='N. Stim'), df_blocks], axis=1)
        
        list_df_blocks.extend([df_blocks])

        print(f'Block {s+1}:\n {df_blocks}')


    ###### FAMILIARIZATION' DATAFRAME ####################################################
    ## Upload familiarization file as a dataframe
    filepath_fam = f'{path_subj_folder}\{filename_xlsx_familiarization}'
    df_fam = pd.read_excel(filepath_fam)

    ## Cue command
    cue_command = df_fam.loc[df_fam['Stimulation type'] == 'Cue'].iloc[0, 1:df_fam.shape[1]].tolist()
    cmd_str_cue = GenerateCommand(cue_command[1:len(cue_command)], path_subj_folder)
    print(f'\nCue:   {cmd_str_cue}')

    ## Pause command
    pause_command = df_fam.loc[df_fam['Stimulation type'] == 'Pause'].iloc[0, 1:df_fam.shape[1]].tolist()
    cmd_str_pause = GenerateCommand(pause_command[1:len(pause_command)], path_subj_folder)
    print(f'Pause: {cmd_str_pause}')


    ## Break command
    break_command = df_fam.loc[df_fam['Stimulation type'] == 'Break'].iloc[0, 1:df_fam.shape[1]].tolist()
    break_code = df_fam.loc[df_fam['Stimulation type'] == 'Break'].iloc[0, 1].tolist()
    cmd_str_break = GenerateCommand(break_command[1:len(break_command)], path_subj_folder)
    break_command.insert(1, None)
    break_command.insert(1, None)
    break_command.insert(1, None)
    print(f"Break: {cmd_str_break}")


    ###### CREATE STIMULATION DATA FRAME ####################################################
    ## Concatenate blocks adding break
    df_stim = pd.DataFrame(columns=['Block', 'N. Stim','Class', 'N. Comb', 'Duration','Force (index)','Force (middle)','Force (ring)', 'Temperature','Frequency'])
    df_stim.loc[0,:] = break_command
    
    row = df_stim.shape[0]
    for s in range(n_blocks): 
        df_temporary = list_df_blocks[s]
        shape_to_add = df_temporary.shape[0]
        df_temporary = pd.concat([pd.Series([s+1]*shape_to_add, name='Block'), df_temporary], axis=1)

        for i in range(shape_to_add): 
            df_stim.loc[row, :] = df_temporary.iloc[i, :].tolist()
            row += 1
        df_stim.loc[row, :] = break_command
        row += 1
    df_stim['Block'] = df_stim['Block'].replace(break_code, "BREAK")


    ## Create command columns 
    cmd_columns = []
    n_comb_column = df_stim['N. Comb'].to_list()
    n_block_columns = df_stim['Block'].to_list()
    n_stim_columns = df_stim['N. Stim'].to_list()
    class_flag_column = df_stim['Class'].to_list()

    for i in range(df_stim.shape[0]): 
        comb_type = n_comb_column[i]
        class_flag = class_flag_column[i]

        if comb_type == None:
            ## Break command
            trigger = df_trigger['Trigger'].loc[df_trigger['Trigger name'] == 'Break'].iloc[0].tolist()
            command = f"cmd : {trigger} : {cmd_str_break} : end "

        else: 
            ## Stimulation or Stimulation+Classificatin command
            trigger_cue = df_trigger['Trigger'].loc[df_trigger['Trigger name'] == 'Cue'].iloc[0].tolist()
            trigger_pause = df_trigger['Trigger'].loc[df_trigger['Trigger name'] == 'Pause'].iloc[0].tolist()
            
            if class_flag == None: 
                ## Only stimulation
                trigger = df_trigger['Trigger'].loc[df_trigger['Trigger name'] == 'Stimulation'].iloc[0].tolist()
            else: 
                ## Stimulation + CLassification
                trigger = df_trigger['Trigger'].loc[df_trigger['Trigger name'] == 'Stimulation and Classification'].iloc[0].tolist()
        
            str_cmd_stim = cmd_list[comb_type-1]
            command = f"cmd : {n_block_columns[i]} : {n_stim_columns[i]} : {trigger} : {int(comb_type + trigger)} : {str_cmd_stim} : {trigger_cue} : {cmd_str_cue} : {trigger_pause} : {cmd_str_pause} : end "
        
        cmd_columns.extend([command])


    ## Add command column to stimualtion data frame
    df_stim['Command'] = cmd_columns

    print(f'\n\nEXPERIMENTAL SEQUENCE data frame:\n{df_stim}')



    ###### SAVE DATA FRAMES ####################################################
    ## Upload of the parameters as a dataframe
    old_filepath_experiment = f'{path_subj_folder}\{filename_xlsx_experiment}'
    new_filename_xlsx_experiment = f"{subject_ID}_experiment.xlsx"
    new_filepath_experiment = f'{path_subj_folder}\{new_filename_xlsx_experiment}'   
    shutil.copy2(old_filepath_experiment, new_filepath_experiment)

    with pd.ExcelWriter(new_filepath_experiment, mode = 'a', engine='openpyxl', if_sheet_exists='overlay') as workbook:
        for s in range(n_blocks): 
            df_to_save = list_df_blocks[s]
            df_to_save.to_excel(workbook, sheet_name = list_sheet_blocks[s], index=False)
        df_stim.to_excel(workbook, sheet_name = sheet_stim, index=False)



    print(f"\n\nExperimental setup SAVED in: \n{new_filepath_experiment}\n\n")
    
    return new_parameters

# import os
# subject_ID = "subject_p003"
# path_folder_experiment = rf"C:\Users\nicole\Documents\GitHub\ABP_project\EXPERIMENT"
# path_results_folder = rf"{path_folder_experiment}\RESULTS" 
# path_subj_folder = os.path.join(path_results_folder, f"{subject_ID}")
# ExpSetup(subject_ID, path_subj_folder)
