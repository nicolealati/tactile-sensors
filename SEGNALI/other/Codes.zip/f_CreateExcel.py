## Libraries
import numpy as np, pandas as pd
from FUNC import CleanTerminal
from FUNC import DefineNCombs, CreateAllCombinations


def CreateExcel(path_subj_folder):

    CleanTerminal()
    print("\nCREATE CSV FILES\n") 



    ###### CREATE XLSX FILES  ####################################################
    # Filepaths
    path_parameters = f"{path_subj_folder}\_xlsx_parameters.xlsx"                                 
    path_combinations = f"{path_subj_folder}\_xlsx_combinations.xlsx"                       
    path_familiarization = f"{path_subj_folder}\_xlsx_familiarization.xlsx"                                  

    # Sheets
    sheet_parameters = "Parameters"
    sheet_familiarization =  "Familiarization"
    sheet_combinations =  "Combinations"



    ###### PARAMETERS DATAFRAME  ####################################################
    ### Upload of the parameters as a dataframe
    df_parameters = pd.read_excel(path_parameters, sheet_name=sheet_parameters)
    
    print(f'\nParameter dataframe: \n\n{df_parameters}\n')

    ## Set parameters
    # Code for each stimulation (int)
    code_cue = df_parameters['Code'].loc[df_parameters['Data'] == 'Cue'].astype(int).to_list()[0]
    code_force = df_parameters['Code'].loc[df_parameters['Data'] == 'Force'].astype(int).to_list()[0]
    code_vibr = df_parameters['Code'].loc[df_parameters['Data'] == 'Vibration'].astype(int).to_list()[0]
    code_pause = df_parameters['Code'].loc[df_parameters['Data'] == 'Pause'].astype(int).to_list()[0]
    code_break = df_parameters['Code'].loc[df_parameters['Data'] == 'Break'].astype(int).to_list()[0]

    # Duration of each stimilation (float)
    dur_cue = df_parameters['Duration'].loc[df_parameters['Data'] == 'Cue'].astype(float).to_list()[0]
    dur_stim = df_parameters['Duration'].loc[df_parameters['Data'] == 'Stimulation'].astype(float).to_list()[0]
    dur_pause = df_parameters['Duration'].loc[df_parameters['Data'] == 'Pause'].astype(float).to_list()[0]
    dur_break = df_parameters['Duration'].loc[df_parameters['Data'] == 'Break'].astype(float).to_list()[0]

    # Values of force (float)
    force_toreplace= df_parameters['Force'].loc[df_parameters['Data'] == 'Low'].astype(float).to_list()[0]
    force_max = df_parameters['Force'].loc[df_parameters['Data'] == 'Max'].astype(float).to_list()[0]
    force_cue = df_parameters['Force'].loc[df_parameters['Data'] == 'Cue'].astype(float).to_list()[0] 
    force_pause = df_parameters['Force'].loc[df_parameters['Data'] == 'Pause'].astype(float).to_list()[0]  
    force_break = df_parameters['Force'].loc[df_parameters['Data'] == 'Break'].astype(float).to_list()[0]  

    # Values of temperature (float)
    temp_cue = df_parameters['Temperature'].loc[df_parameters['Data'] == 'Cue'].astype(float).to_list()[0]
    temp_ambient = df_parameters['Temperature'].loc[df_parameters['Data'] == 'Low'].astype(float).to_list()[0]
    temp_pause = df_parameters['Temperature'].loc[df_parameters['Data'] == 'Pause'].astype(float).to_list()[0]
    temp_break = df_parameters['Temperature'].loc[df_parameters['Data'] == 'Break'].astype(float).to_list()[0]

    # Values in frequency (int)
    frequency_constant = df_parameters['Frequency'].loc[df_parameters['Data'] == 'Min'].astype(int).to_list()[0]
    frequency_low = df_parameters['Frequency'].loc[df_parameters['Data'] == 'Low'].astype(int).to_list()[0]
    frequency_high = df_parameters['Frequency'].loc[df_parameters['Data'] == 'Max'].astype(int).to_list()[0]
    frequency_cue = df_parameters['Frequency'].loc[df_parameters['Data'] == 'Cue'].astype(int).to_list()[0]
    frequency_pause = df_parameters['Frequency'].loc[df_parameters['Data'] == 'Pause'].astype(int).to_list()[0]
    frequency_break = df_parameters['Frequency'].loc[df_parameters['Data'] == 'Break'].astype(int).to_list()[0]
    
    # List of the parameters used for checking value validity
    list_duration = [dur_stim]  
    list_force = [force_toreplace, force_max]
    list_temperature = [temp_ambient]
    list_frequency = [frequency_constant, frequency_low, frequency_high]

    parameter_list = [list_duration, list_force, list_temperature, list_frequency]
    name_list = ['Duration','Force', 'Temperature', 'Frequency' ]



    #########################################################################
    ###### COMBINATIONS  ####################################################
    # Calculate number of combinations
    ncomb = DefineNCombs(parameter_list)

    # Create dataframe with all combinations
    df_comb = CreateAllCombinations(name_list, parameter_list, ncomb)

    # Replace nan force values with string 'Basal'
    df_comb['Force'] = df_comb['Force'].replace(float('nan'), 'Basal Min')
    df_comb['Force'] = df_comb['Force'].replace(1, 'Basal Max')    
    
    # Insert columns
    df_comb.insert(0, 'N. Comb', np.linspace(1, ncomb, ncomb))   # Combinaton number
    df_comb.insert(3, 'Force (index)', df_comb['Force'].copy())   # Force of index finger
    df_comb.insert(4, 'Force (middle)', df_comb['Force'].copy())  # Force of middle finger
    df_comb.insert(5, 'Force (ring)', df_comb['Force'].copy())    # Force of ring finger

    # Drop force columnn
    df_comb = df_comb.drop('Force', axis =1)    
    
    # Convert columns in int values                       
    df_comb['N. Comb'] = df_comb['N. Comb'].astype(int)
    df_comb['Frequency'] = df_comb['Frequency'].astype(int)

    print(f'\n\nCombination dataframe: \n{df_comb}\n\n') 

    # Save dataframe into xlsx file
    with pd.ExcelWriter(path_combinations, mode = 'a', engine='openpyxl', if_sheet_exists='overlay') as workbook:    
        df_comb.to_excel(workbook, sheet_name=sheet_combinations, index=False)

    
    
    ############################################################################
    ###### FAMILIARIZATION  ####################################################
    # 2 forces, 1 temperature, 3 vibration types, 3 intersteps, 1 pause

    # Insert columns
    stim = ['Force Min', 'Force Max', 
            'Frequency Constant', 'Frequency Low', 'Frequency High',
            'Cue', 'Pause', 'Break']
      
    # Set columns 'Code'
    code = [code_force, code_force,                                # Forces
            code_vibr, code_vibr, code_vibr,                       # Frquencies
            code_cue, code_pause, code_break]                      # Cue, Pause, Break

    # Set columns 'Duration'
    duration = [dur_stim, dur_stim,                         # Forces
                dur_stim, dur_stim, dur_stim,               # frequencies
                dur_cue, dur_pause, dur_break]              # Cue, Pause, Break

    # Set columns 'Force'
    force_to_replace = float('nan')
    force = [force_to_replace, force_max,                                # Forces
             force_to_replace, force_to_replace, force_to_replace,       # Types     
             force_cue, force_pause, force_break ]                       # Cue, Pause, Break

    # Set columns 'Temperature'
    temperature = [temp_ambient, temp_ambient,                          # Forces
                   temp_ambient, temp_ambient, temp_ambient,            # Types        
                   temp_cue, temp_pause, temp_break]                    # Cue, Pause, Break

    # Set columns 'Frequency'
    frequency = [frequency_constant, frequency_constant,                         # Force
                 frequency_constant, frequency_low, frequency_high,              # Type
                 frequency_cue, frequency_pause, frequency_break]                # Cue, Pause, Break
                   
    # Create the dataframe
    df_familiarization = pd.DataFrame()
    df_familiarization['Stimulation type'] = stim
    df_familiarization['Code'] = code
    df_familiarization['Duration'] = duration
    df_familiarization['Force'] = force
    df_familiarization['Temperature'] = temperature
    df_familiarization['Frequency'] = frequency
        
    # Replace nan values of force with string 'Basal'
    df_familiarization['Force'] = df_familiarization['Force'].replace(float('nan'), 'Basal Min')
    df_familiarization['Force'] = df_familiarization['Force'].replace(1, 'Basal Max')

    # Insert columns
    df_familiarization.insert(4, 'Force(index)', df_familiarization['Force'].copy())   # Force of index finger
    df_familiarization.insert(5, 'Force(middle)', df_familiarization['Force'].copy())  # Force of middle finger
    df_familiarization.insert(6, 'Force(ring)', df_familiarization['Force'].copy())    # Force of ring finger

    # Drop force columnn
    df_familiarization = df_familiarization.drop('Force', axis =1)  

     # Convert columns in int values                       
    df_familiarization['Code'] = df_familiarization['Code'].astype(int)
    df_familiarization['Frequency'] = df_familiarization['Frequency'].astype(int)
    
    print(f'\n\nFamiliarization dataframe:\n{df_familiarization}\n')
    
    # Save dataframe into xlsx file
    with pd.ExcelWriter(path_familiarization, mode = 'a', engine='openpyxl', if_sheet_exists='overlay') as workbook:    
        df_familiarization.to_excel(workbook, sheet_name=sheet_familiarization, index=False)


    
    print("Create csv DONE")


# import os
# name_surname =["test", "test", "subject_0"]
# path_folder = rf"C:\Users\nicole\Documents\GitHub\ABP_project\EXPERIMENT"
# path_source_folder = rf"{path_folder}\Templates"
# subj_folder = rf"{path_folder}\RESULTS" 
# subj_folder_name = "subject_test"
# path_subj_folder = os.path.join(subj_folder, subj_folder_name)
# CreateXlsx(path_subj_folder)