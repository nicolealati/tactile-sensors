# Libraries 
import os
import shutil
from FUNC import CleanTerminal, ClosePrompts
from FUNC_GUI import OpenGuiSubjectID,  OpenGuiPc, OpenGuiSelection

## Clean terminal
CleanTerminal()



###### FOLDERS, PATHS AND FILENAMES ####################################################
selection = OpenGuiPc()
# selection = "personal"

if selection == "personal":
    path_folder_experiment = rf"C:\Users\nicole\Documents\GitHub\ABP_project\EXPERIMENT"

if selection == "alienware": 
    path_folder_experiment = rf"D:\Nicole_JS"

path_templates_folder = rf"{path_folder_experiment}\Templates"
path_results_folder = rf"{path_folder_experiment}\RESULTS" 

## Import name, surname, and number of the subject
subject_ID = OpenGuiSubjectID()
# subject_ID = "subject_p003"

## Prompts
path_prompt_csharp_calibration = rf"{path_folder_experiment}\Codes\PRE_Calib_csharp\bin\Debug\net6.0"
path_prompt_csharp_fam_class = rf"{path_folder_experiment}\Codes\PRE_Fam_Class_csharp\bin\Debug\net6.0"
path_prompt_csharp_experiment = rf"{path_folder_experiment}\Codes\EXP_csharp\bin\Debug\net6.0"

filename_prompt_csharp_calibration = "PRE_Calib_csharp.exe" 
filename_prompt_csharp_fam_class = "PRE_Fam_Class_csharp.exe"
filename_terminal_csharp_experiment = "EXP_csharp.exe"

path_prompt_csharp_calibration = rf"{path_prompt_csharp_calibration}\{filename_prompt_csharp_calibration}"
path_prompt_csharp_fam_class = rf"{path_prompt_csharp_fam_class}\{filename_prompt_csharp_fam_class}"
path_prompt_csharp_experiment = rf"{path_prompt_csharp_experiment}\{filename_terminal_csharp_experiment}"

# Check if the folder of the subject exists
path_subj_folder = os.path.join(path_results_folder, f"{subject_ID}")

## Create folder for subject
if not os.path.exists(path_subj_folder):
    shutil.copytree(path_templates_folder, path_subj_folder)



###### CREATE XLSX FILES  ####################################################
## Create xlsx for combinations and familiarization
from f_CreateExcel import CreateExcel
CreateExcel(path_subj_folder)



###### SELECTION ####################################################
flag_list = [True, True, True, False, False, False, False]
selection = None
while selection != 0:
    selection = OpenGuiSelection(flag_list)
    print(f"Selection = {selection}")

    if selection == 1:
        ## Insert subject data
        from f_SubjectInfo import SubjectInfo
        SubjectInfo(subject_ID, path_subj_folder)

    if selection == 2: 
        ## Insert thimbles' values
        from f_Thimbles import InsertThimbles
        InsertThimbles(path_subj_folder)
    
    if selection == 3: 
        ## Force calibration
        from f_ForceCalibration import ForceCalibration
        ForceCalibration(path_subj_folder, filename_prompt_csharp_calibration, path_prompt_csharp_calibration)
        flag_list = [True, True, True, True, True, True, False]

    if selection == 4: 
        ## Familiarization
        from f_Familiarization import Familiarization
        Familiarization(path_subj_folder, filename_prompt_csharp_fam_class, path_prompt_csharp_fam_class)
    
    if selection == 5: 
        ## Classification
        from f_Fam_Classification import Classification
        Classification(subject_ID, path_subj_folder, filename_prompt_csharp_fam_class, path_prompt_csharp_fam_class)

    if selection == 6: 
        ## Exp Setup
        ## Experimental setup
        from f_Exp_Setup import ExpSetup
        parameters = ExpSetup(subject_ID, path_subj_folder)
        flag_list = [True, True, True, True, True, True, True]

    if selection == 7: 
        ## Experiment
        from f_Experiment import Experiment
        Experiment(subject_ID, path_subj_folder, filename_terminal_csharp_experiment, path_prompt_csharp_experiment, parameters)
    

ClosePrompts(filename_prompt_csharp_calibration)
ClosePrompts(filename_prompt_csharp_fam_class)






