from PyQt5 import QtGui
from PyQt5.QtWidgets import QWidget, QLabel, QLineEdit, QHBoxLayout, QVBoxLayout, QPushButton

class ExperimentParameters(QWidget):
    def __init__(self, current_parameters):
        super().__init__()

        self.n_reps = current_parameters[0]
        self.n_blocks = current_parameters[1]
        self.n_class = current_parameters[2]

        self.WindowSetup()

    def WindowSetup(self):
        self.setWindowTitle('Parameters GUI')
        self.setGeometry(700, 400, 400, 500)

        font = QtGui.QFont()
        font.setPointSize(11)

        font_new = QtGui.QFont()
        font_new.setPointSize(9)

        ## REPETITIONS
        self.n_reps_label = QLabel(f"\nN. repetitions of the sequence:   {self.n_reps}")
        self.n_reps_label.setFont(font)      
        self.n_reps_edit = QLineEdit(self)
        self.n_reps_edit.setFont(font)

        self.change_label_1 = QLabel("Insert a new value (if needed):")
        self.change_label_1.setFont(font_new)

        layout_reps = QHBoxLayout()
        layout_reps.addWidget(self.change_label_1)
        layout_reps.addWidget(self.n_reps_edit)


        ## SESSIONS
        self.n_blocks_label = QLabel(f"\nN. blocks:   {self.n_blocks}")
        self.n_blocks_label.setFont(font)
        self.n_blocks_edit = QLineEdit(self)
        self.n_blocks_edit.setFont(font)

        self.change_label_2 = QLabel("Insert a new value (if needed):")
        self.change_label_2.setFont(font_new)

        layout_blocks = QHBoxLayout()
        layout_blocks.addWidget(self.change_label_2)
        layout_blocks.addWidget(self.n_blocks_edit)


        ## CLASSIFICATION
        self.n_class_label = QLabel(f"\nN. classifications of the same combination for each block:    {self.n_class}")
        self.n_class_label.setFont(font)
        self.n_class_edit = QLineEdit(self)
        self.n_class_edit.setFont(font)

        self.change_label_3 = QLabel("Insert a new value (if needed):")
        self.change_label_3.setFont(font_new)

        layout_class = QHBoxLayout()
        layout_class.addWidget(self.change_label_3)
        layout_class.addWidget(self.n_class_edit)

        ## SUBMIT
        self.submit_button = QPushButton('SUBMIT', self)
        self.submit_button.setFont(font)
        self.submit_button.setStyleSheet('background-color: lightgray;')
        self.submit_button.clicked.connect(self.SubmitData)

        self.empty_label = QLabel("")

        layout_vertical = QVBoxLayout()
        layout_vertical.addWidget(self.n_reps_label)
        layout_vertical.addLayout(layout_reps)
        layout_vertical.addWidget(self.n_blocks_label)
        layout_vertical.addLayout(layout_blocks)
        layout_vertical.addWidget(self.n_class_label)
        layout_vertical.addLayout(layout_class)
        layout_vertical.addWidget(self.empty_label)
        layout_vertical.addWidget(self.submit_button)

        self.setLayout(layout_vertical)

    def SubmitData(self):
        self.submit_button.setEnabled(False)
        if self.n_reps_edit.text() != "":
            self.n_reps = int(self.n_reps_edit.text())
        if self.n_blocks_edit.text() != "":
            self.n_blocks = int(self.n_blocks_edit.text())
        if self.n_class_edit.text() != "":
            self.n_class = int(self.n_class_edit.text())
        
        self.new_parameters = [self.n_reps, self.n_blocks, self.n_class]
        self.close()

        return self.new_parameters



