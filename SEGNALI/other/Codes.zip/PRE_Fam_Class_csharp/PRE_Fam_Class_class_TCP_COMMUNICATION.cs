﻿using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Ports;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;

namespace PRE_Fam_Class_csharp
{
    public class PRE_Fam_Class_class_TCP_COMMUNICATION
    {
        private TcpListener server_comm;
        private string str_print = "(TCP_COMMUNICATION) ";

        public PRE_Fam_Class_class_TCP_COMMUNICATION(string tcp_host, int port)
        {
            try
            {
                Console.WriteLine($"\n{str_print}Creating server");
                
                //IPAddress ip_address = IPAddress.Any;
                //IPEndPoint local_end_point = new IPEndPoint(ip_address, port);
                //server_comm = new TcpListener(local_end_point);
                server_comm = new(IPAddress.Parse(tcp_host), port);
                
                Console.WriteLine($"{str_print}Server created \n");
            }
            catch (Exception e) 
            {
                Console.WriteLine($"{str_print}Error: {e.Message}");
            }  
        }

        public TcpClient OpenTcpConnection(int tcp_port)
        {
            // Connect to the sender
            Console.WriteLine($"\n{str_print}Connecting at port {tcp_port} ");
            server_comm.Start();
            TcpClient client_comm = server_comm.AcceptTcpClient();
            Console.WriteLine($"{str_print}Connected\n");
            
            return client_comm;
        }

        public NetworkStream ClientGetStream(TcpClient client_comm)
        {
            Console.WriteLine($"\n{str_print}ClientGetStream");
            NetworkStream stream_comm = client_comm.GetStream();
            Console.WriteLine($"{str_print}ClientGetStream done\n");
            
            return stream_comm;
        }

        public void WaitMessageBack(NetworkStream stream_comm)
        {
            // For get message
            byte[] buffer_comm = new byte[256];

            while (true)
            {
                if (stream_comm.DataAvailable)
                {
                    // Calculate number of received bytes

                    int bytesRead = stream_comm.Read(buffer_comm, 0, buffer_comm.Length);
                    if (bytesRead > 0)
                    {
                        // Decode received 
                        string acknowledgment = Encoding.UTF8.GetString(buffer_comm, 0, bytesRead);
                        Console.WriteLine(acknowledgment);
                        break;
                    } // END if (bytesRead > 0)
                } // END if (stream_comm.DataAvailable)
            } // END while (true)
        } // END WaitMessageBack


        public void CloseTcpConnection(bool listening_flag, int tcp_port)
        {
            if (listening_flag)
            {
                Console.WriteLine($"\n{str_print}Disconnecting port {tcp_port} ");
                server_comm.Stop();
                Console.WriteLine($"{str_print}Disconnected\n");
            }
        }

        


    }
}
