﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Concurrent;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;
using PRE_Fam_Class_csharp;
using WeArt.Core;

public class PRE_Fam_Class_MAIN
{
    // TO MODIFY 
    static bool use_touchdiver_flag = true;
    static string str_print = "(MAIN) ";
    

    static PRE_Fam_Class_class_TCP_COMMUNICATION handler_tcp_comm;
    static PRE_Fam_Class_class_HANDLE_COMMUNICATION handler_comm_thread;
    static PRE_Fam_Class_class_HANDLE_STIMULATION handler_stim_thread;


    // TCP CONNECTIONS
    static string tcp_host = "127.0.0.1"; 
    static int tcp_comm_port = 5_555;
    static bool stop_comm_flag = false;


    private static void Main(string[] args)
    {
        Console.WriteLine($"{str_print}C# started");

        // Create the queue form storing the lists of int/float for the stimulation
        ConcurrentQueue<List<string>> command_queue = new();
        
        // COMMUNICATION THREAD - Command received from Python client_gui, handled and stored in the queue
        Task CommunicationTask = Task.Run(() => ManageCommunication(command_queue));
        // STIMULATION THREAD - Command dequeued from queue and used to provide stimulation
        Task StimulationTask = Task.Run(() => ManageStimulation(command_queue));

        // Await both tasks end
        Task TaskManager = Task.WhenAll(CommunicationTask, StimulationTask);
        TaskManager.Wait();

        // Close the serial port
        handler_tcp_comm.CloseTcpConnection(stop_comm_flag, tcp_comm_port);

        Console.WriteLine($"{str_print}Both tasks completed");
    }
    // END Main

    static async void ManageCommunication(ConcurrentQueue<List<string>> primary_queue)
    {

        handler_tcp_comm = new PRE_Fam_Class_class_TCP_COMMUNICATION(tcp_host, tcp_comm_port);
        TcpClient client_stim = handler_tcp_comm.OpenTcpConnection(tcp_comm_port);
        NetworkStream stream_stim = handler_tcp_comm.ClientGetStream(client_stim);

        handler_comm_thread = new PRE_Fam_Class_class_HANDLE_COMMUNICATION();
        handler_comm_thread.CommandHandle(stream_stim, primary_queue, true);
        

    } // END MenageCommands

    static async void ManageStimulation(ConcurrentQueue<List<string>> storage_queue)
    {
        handler_stim_thread = new PRE_Fam_Class_class_HANDLE_STIMULATION();
        handler_stim_thread.StimulationHandle(storage_queue, use_touchdiver_flag);
    } // END ManageStimulation
}