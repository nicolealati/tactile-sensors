﻿using System;
using System.Collections;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;

namespace PRE_Fam_Class_csharp
{
    public class PRE_Fam_Class_class_HANDLE_COMMUNICATION
    {
        private string handler;
        private bool loop_flag;
        private string str_print = "(HANDLE_COMMUNICATION) ";

        public PRE_Fam_Class_class_HANDLE_COMMUNICATION()
        {
            handler = string.Empty;
        }

        internal bool CommandHandle(NetworkStream tcp_stream_stim, ConcurrentQueue<List<string>> storage_queue, bool loop_flag)
        {
            Console.WriteLine($"\n{str_print}CommandHandle");

            // Initialize new variables
            byte[] tcp_stim_buffer = new byte[256];     // Buffer to receive commands from sender
            string temporary_string = "";               // Save remaining not-complete retrieved_primary_command

            // While loop to continue listening
            while (loop_flag)
            {
                if (tcp_stream_stim.DataAvailable)
                {
                    // Calculate number of received bytes
                    int n_read_bytes = tcp_stream_stim.Read(tcp_stim_buffer, 0, tcp_stim_buffer.Length);

                    if (n_read_bytes > 0)
                    {
                        // Decode into string (using UTF-8 encoding)
                        string str_decoded_command;
                        str_decoded_command = Encoding.UTF8.GetString(tcp_stim_buffer, 0, n_read_bytes);
                        //Console.WriteLine($"(HANDLE_COMMUNICATION_controller)     Recv = <<{str_decoded_command}>>");

                        // Concatenate previous not-complete command at the beginning of the current command
                        str_decoded_command = temporary_string + str_decoded_command;
                        temporary_string = "";

                        if (str_decoded_command != null)
                        {
                            // Replace space with null and Split string command by "cmd,"
                            string[] splitted_command = str_decoded_command.Replace(" ", "").Split("cmd:");

                            // Empty storage list for complete commands (only)
                            var complete_str_commands_list = new List<string[]> { };

                            // Iterate each string element of the string array
                            foreach (var element in splitted_command)
                            {
                                // Check whether the string length >= 4 
                                if (element.Length >= 4)
                                {
                                    //Console.WriteLine($"\n{str_print}     Element: {element}, length = {element.Length}");

                                    // Take the last three characters of the string
                                    string last_chars = element.Substring(element.Length - 4);

                                    // Check if the last 3 chars of the element are "end"
                                    if (last_chars == ":end")
                                    {
                                        // Consider  string from the beginning to ":end" (excluded), and split by ":"
                                        string[] splitted_str_element = element.Substring(0, element.Length - 4).Split(":");

                                        // Check correctness of the retrieved_primary_command
                                        bool check_flag = CheckCommand(splitted_str_element);
                                        if (check_flag)
                                        {
                                            //Console.WriteLine($"\n(HANDLE_COMMUNICATION_controller) Sent command  << {string.Join(" ", splitted_element)} >>");

                                            // Create a string list
                                            List<string> splitted_commands_list = new();

                                            // Check length of string array to enqueue the proper command list
                                            if (splitted_str_element.Length == 1) // START / STOP command   
                                            {
                                                // Add to list
                                                splitted_commands_list.Add(splitted_str_element[0]);  // trigger start/stop 
                                                // Enqueue list to the queue
                                                storage_queue.Enqueue(splitted_commands_list);
                                                // Change flag value into false if stop command to exit from the loop
                                                loop_flag = (splitted_str_element[0] == "51") ? false : true;
                                            }
                                            else if (splitted_str_element.Length == 2)  // BREAK command
                                            {
                                                // Add to list
                                                splitted_commands_list.Add(splitted_str_element[0]);  // trigger break
                                                splitted_commands_list.Add(splitted_str_element[1]);  // command
                                                // Enqueue list to the queue
                                                storage_queue.Enqueue(splitted_commands_list);
                                            }
                                            else if (splitted_str_element.Length == 9)
                                            {
                                                // Add to list (trigger in 1st position)
                                                splitted_commands_list.Add(splitted_str_element[2]); // trigger stimulation 
                                                splitted_commands_list.Add(splitted_str_element[0]); // session
                                                splitted_commands_list.Add(splitted_str_element[1]); // n stim 
                                                splitted_commands_list.Add(splitted_str_element[3]); // trigger type stimulation
                                                splitted_commands_list.Add(splitted_str_element[4]); // retrieved_primary_command stimulation + classification
                                                splitted_commands_list.Add(splitted_str_element[5]); // trigger cue
                                                splitted_commands_list.Add(splitted_str_element[6]); // retrieved_primary_command cue
                                                splitted_commands_list.Add(splitted_str_element[7]); // trigger pause
                                                splitted_commands_list.Add(splitted_str_element[8]); // retrieved_primary_command pause
                                                // Enqueue list to the queue
                                                storage_queue.Enqueue(splitted_commands_list);
                                            } // END f (splitted_str_element.Length == n)
                                        } // END if (check_flag)

                                    } // if (last_chars == ":end") NOT VERIFIED
                                    else
                                    {
                                        temporary_string = element;
                                    } // END if (last_chars == ":end")

                                } // if (element.Length >= 4) NOT VERIFIED
                                else
                                {
                                    temporary_string = element;
                                } // END if (element.Length >= 4)

                            } // END foreach (var element in splitted_command)
                        } // END if (str_decoded_command != null)
                    } // END if (n_read_bytes > 0)
                } // END if (tcp_stream_stim.DataAvailable) 
            } // END while loop

            Console.WriteLine($"{str_print}CommandHandle done\n");

            bool stop_listening_flag = false;
            return stop_listening_flag; 

        } // END CommandHandle


        static bool CheckCommand(string[] strings_array)
        {
            // Length of the retrieved_primary_command array
            int[] lengths = { 1, 2, 9 };


            if (strings_array.Length == lengths[0] || strings_array.Length == lengths[1] || strings_array.Length == lengths[2])
            {
                return true;
            }
            else
            {
                Console.WriteLine($"\nERROR in  << {string.Join(", ", strings_array)}\n >>");
                return false;
            }
        } // END CheckCommand
    }
}
