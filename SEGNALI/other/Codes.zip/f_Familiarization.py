## Libraries
import pandas as pd
import socket
import time
from datetime import datetime
from FUNC import CleanTerminal
from FUNC import RunNewPrompt, ClosePrompts
from FUNC import ImportBasalForce, GenerateCommand 
from FUNC_GUI import OpenGuiFamiliarization


def Familiarization(path_subj_folder, filename_prompt_csharp, path_prompt_csharp):

    CleanTerminal()
    print("\nFAMILIARIZATION TASK\n")              



    ###### FILENAME AND SHEET NAME ####################################################
    ## Filenames
    filename_xlsx_familiarization = "_xlsx_familiarization.xlsx"          
    filename_xlsx_force = "_xlsx_thimble_basal.xlsx"
    filename_xlsx_triggers = "_xlsx_triggers_dict.xlsx"

    # Sheets
    sheet_force = "Basal Forces"


    ###### FAMILIARIZATION SESSION ####################################################
    try: 
        ClosePrompts(filename_prompt_csharp)
        RunNewPrompt(path_prompt_csharp)



        ###### SOCKET ####################################################
        ## Create socket with csharp file
        host, port = "127.0.0.1", 5555
        aClientSocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        aClientSocket.connect((host, port))
    

        ###### FAMILIARIZATION DATA FRAME ####################################################
        ## Upload familiarization file as a dataframe
        path_xlsx_familiarization = f'{path_subj_folder}\{filename_xlsx_familiarization}'
        df_fam = pd.read_excel(path_xlsx_familiarization)

        # Extract commands for cue and  pause
        cue_command = df_fam.loc[df_fam['Stimulation type'] == 'Cue'].iloc[0, 1:df_fam.shape[1]].tolist()
        pause_command = df_fam.loc[df_fam['Stimulation type'] == 'Pause'].iloc[0, 1:df_fam.shape[1]].tolist()

        # Convert into strings
        cmd_str_cue = GenerateCommand(cue_command[1:len(cue_command)], path_subj_folder)
        cmd_str_pause = GenerateCommand(pause_command[1:len(pause_command)], path_subj_folder)



        ###### FORCE DATA FRAME ####################################################
        ## Upload basal force file as a dataframe
        path_xlsx_force = f'{path_subj_folder}\{filename_xlsx_force}'
        df_basal_forces = pd.read_excel(path_xlsx_force, sheet_name=sheet_force)

        print(f'\naBasal forces dataframe: \n\n{df_basal_forces}\n\n')

        # Take from the dataframe max and min force values for each finger
        force_min_index = df_basal_forces.iloc[2, 1].tolist()
        force_min_middle = df_basal_forces.iloc[2, 2].tolist()
        force_min_ring = df_basal_forces.iloc[2, 3].tolist()
        force_max_index = df_basal_forces.iloc[3, 1].tolist()
        force_max_middle = df_basal_forces.iloc[3, 2].tolist()
        force_max_ring = df_basal_forces.iloc[3, 3].tolist()

        ## Change 'Basal' with corresponding force value
        force_to_replace = 'Basal Min'
        df_fam['Force(index)'] = ImportBasalForce(df_fam['Force(index)'].to_list(), force_to_replace, force_min_index)
        df_fam['Force(middle)'] = ImportBasalForce(df_fam['Force(middle)'].to_list(), force_to_replace, force_min_middle)
        df_fam['Force(ring)'] = ImportBasalForce(df_fam['Force(ring)'].to_list(), force_to_replace, force_min_ring)
        force_to_replace = 'Basal Max'
        df_fam['Force(index)'] = ImportBasalForce(df_fam['Force(index)'].to_list(), str(force_to_replace), force_max_index)
        df_fam['Force(middle)'] = ImportBasalForce(df_fam['Force(middle)'].to_list(), str(force_to_replace), force_max_middle)
        df_fam['Force(ring)'] = ImportBasalForce(df_fam['Force(ring)'].to_list(), str(force_to_replace), force_max_ring)
        
        print(f'\n\nUPDATE dataframe: \n\n{df_fam}\n\n')



        ###### TRIGGERS DATA FRAME ####################################################
        ## Extract trigger dictionary from txt file
        df_trigger = pd.DataFrame()
        df_trigger = pd.read_excel(f"{path_subj_folder}\{filename_xlsx_triggers}")

        # Extract triggers 
        trigger_start = df_trigger['Trigger'].loc[df_trigger['Trigger name'] == 'Start Experiment'].iloc[0].tolist()
        trigger_stop = df_trigger['Trigger'].loc[df_trigger['Trigger name'] == 'Stop Experiment'].iloc[0].tolist()
        trigger_cue = df_trigger['Trigger'].loc[df_trigger['Trigger name'] == 'Cue'].iloc[0].tolist()
        trigger_pause = df_trigger['Trigger'].loc[df_trigger['Trigger name'] == 'Pause'].iloc[0].tolist()
        trigger_stim = df_trigger['Trigger'].loc[df_trigger['Trigger name'] == 'Stimulation'].iloc[0].tolist() 



        ###### START FAMILIARIZATION #################################################
        # Time to wait before printing new selections
        duration_sleep = df_fam['Duration'].iloc[0] + df_fam['Duration'].iloc[5] + df_fam['Duration'].iloc[6] + 0.1

        start_calibration = datetime.now()
        while True:  

            # Send START command to connect the middleware 
            command = f"cmd : {trigger_start} : end "
            print(f'\nSent command <<{command}>>')
            aClientSocket.send(command.encode("utf-8"))

            while True:
                # Select stimulation to provide
                selection = OpenGuiFamiliarization() 
                # For each selection:
                # Define the line in the dataframe corresponding to the command,
                # and eventually to the interstep command

                if selection == 'min':
                    n = 0
                elif selection == 'max':
                    n = 1
                elif selection == 'low':
                    n = 3
                elif selection == 'high':
                    n = 4
                elif selection == 'stop':
                    break
                     
                # Set commands  
                cmd_str_stim = GenerateCommand(df_fam.iloc[n, 2:df_fam.shape[1]].tolist(), path_subj_folder)
                command = f"cmd : 0 : 0 : {trigger_stim} : {int(n + 1 + trigger_stim)} : {cmd_str_stim} : {trigger_cue} : {cmd_str_cue} : {trigger_pause} : {cmd_str_pause} : end "
                aClientSocket.send(command.encode("utf-8"))

                time.sleep(duration_sleep)

            break 
            
        end_time = datetime.now()  
        
        
        
        ###### TIMESTAMP #################################################
        ## Count time elapsed
        time_difference = end_time - start_calibration
        time_elapsed_min = int(time_difference.total_seconds() // 60)
        time_elapsed_sec = int(time_difference.total_seconds() % 60)

        print(f'\n\nTime elapsed: {time_elapsed_min}m : {time_elapsed_sec}s')
       


    finally:
        # Send STOP command to disconnect the middleware
        command = f"cmd : {trigger_stop} : end"
        print(f'\nSent command <<{command}>>')
        aClientSocket.send(command.encode("utf-8"))
        


        print("\nFamiliarization DONE\n\n")


# import os
# name_surname =["", "", "subject_test"]
# path_folder = rf"C:\Users\nicole\Documents\GitHub\ABP_project\EXPERIMENT"
# path_source_folder = rf"{path_folder}\Templates"
# subj_folder = rf"{path_folder}\RESULTS" 
# subj_folder_name = "subject_test"
# path_subj_folder = os.path.join(subj_folder, subj_folder_name)
# filename_prompt_csharp = "PRE_Fam_Class__csharp.exe"
# path_prompt_csharp = rf"C:\Users\nicole\Documents\GitHub\ABP_project\EXPERIMENT\Codes\PRE_Fam_Class_csharp\bin\Debug\net6.0\{filename_prompt_csharp}"

# Familiarization(path_subj_folder, filename_prompt_csharp, path_prompt_csharp)


