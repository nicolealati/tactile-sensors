## Libraries
import pandas as pd
from FUNC import CleanTerminal
from FUNC_GUI import OpenGuiThimble

def InsertThimbles(subj_folder_name):
    
    ###### FILENAME AND SHHET NAME ####################################################
    filename_xlsx_thimble = "_xlsx_thimble_basal.xlsx" 
    sheet_thimbles = "Thimbles"



    ##########################################################################
    CleanTerminal()
    print("\nTHIMBLES\n")



    ###### THIMBLES' VALUES ####################################################
    thimbles_values = OpenGuiThimble()
    index_column = thimbles_values[0]
    print(index_column)
    middle_column = thimbles_values[1]
    ring_column = thimbles_values[2]

    ## Create data frame
    path_xlsx_thimbles = f'{subj_folder_name}\{filename_xlsx_thimble}'
    df_thimbles = pd.read_excel(path_xlsx_thimbles, sheet_thimbles)
    df_thimbles['Index'] = index_column
    df_thimbles['Middle'] = middle_column
    df_thimbles['Ring'] = ring_column

    print(f'\n\nThimbles:\n{df_thimbles}\n\n')

    ## Save dataframe
    with pd.ExcelWriter(path_xlsx_thimbles, mode = 'a', engine='openpyxl', if_sheet_exists='overlay') as workbook:    
            df_thimbles.to_excel(workbook, sheet_thimbles, index=False)

    print("\n\nInsert thimbles values DONE")

