from PyQt5 import QtGui
from PyQt5.QtWidgets import QWidget, QLabel, QVBoxLayout, QPushButton

class StartClassificationWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.WindowSetup()


    def WindowSetup(self):
        self.setWindowTitle('Start Classification GUI')
        self.setGeometry(700, 400, 300, 200)

        font = QtGui.QFont()
        font.setPointSize(14)

        self.label = QLabel("Ready to start?")
        self.label.setFont(font)

        self.close_button = QPushButton("START", self)
        self.close_button.setFont(font)
        self.close_button.setStyleSheet('background-color: #7d7;')
        self.close_button.clicked.connect(self.CloseFunction)

        layout = QVBoxLayout()
        layout.addWidget(self.label)
        layout.addWidget(self.close_button)
        
        self.setLayout(layout)

    
        
    
    def CloseFunction(self):
        self.close()
        


