from PyQt5 import QtGui
from PyQt5.QtWidgets import QWidget, QLabel, QLineEdit, QPushButton, QGridLayout


class Thimbles(QWidget):
    def __init__(self):
        super().__init__()
        self.WindowSetup()

    def WindowSetup(self):
        self.setWindowTitle('Thimbles GUI')
        self.setGeometry(700, 400, 550, 300)

        font_label = QtGui.QFont()
        font_label.setPointSize(12)
        font_label.setBold(True)

        font_edit = QtGui.QFont()
        font_edit.setPointSize(13)

        font_submit = QtGui.QFont()
        font_submit.setPointSize(14)

        self.grid_layout = QGridLayout()
        self.grid_layout.setSpacing(10)

        # Create column labels
        self.empty_label = QLabel("      ", self)
        self.index_label = QLabel("INDEX", self)
        self.middle_label = QLabel("MIDDLE", self)
        self.ring_label = QLabel("RING", self)
        
        self.index_label.setFont(font_label)
        self.middle_label.setFont(font_label)
        self.ring_label.setFont(font_label)

        self.grid_layout.addWidget(self.empty_label, 0, 0)
        self.grid_layout.addWidget(self.empty_label, 0, 1)
        self.grid_layout.addWidget(self.index_label, 0, 2)
        self.grid_layout.addWidget(self.middle_label, 0, 3)
        self.grid_layout.addWidget(self.ring_label, 0, 4)

        # Create row labels
        self.left_label = QLabel("LEFT ", self)
        self.right_label = QLabel("RIGHT ", self)

        self.left_label.setFont(font_label)
        self.right_label.setFont(font_label)

        self.grid_layout.addWidget(self.left_label, 1, 0)        
        self.grid_layout.addWidget(self.empty_label, 2, 0)
        self.grid_layout.addWidget(self.right_label, 3, 0)
        self.grid_layout.addWidget(self.empty_label, 4, 0)

        # Create row labels
        self.large_left_label = QLabel("Large", self)
        self.small_left_label = QLabel("Small ", self)
        self.large_right_label = QLabel("Large", self)
        self.small_right_label = QLabel("Small ", self)
        
        self.large_left_label.setFont(font_edit)
        self.small_left_label.setFont(font_edit)
        self.large_right_label.setFont(font_edit)
        self.small_right_label.setFont(font_edit)

        self.grid_layout.addWidget(self.large_left_label, 1, 1)        
        self.grid_layout.addWidget(self.small_left_label, 2, 1)
        self.grid_layout.addWidget(self.large_right_label, 3, 1)
        self.grid_layout.addWidget(self.small_right_label, 4, 1)

        # Create edit
        self.large_index_left_edit = QLineEdit(self)
        self.large_middle_left_edit = QLineEdit(self)
        self.large_ring_left_edit = QLineEdit(self)

        self.small_index_left_edit = QLineEdit(self)
        self.small_middle_left_edit = QLineEdit(self)
        self.small_ring_left_edit = QLineEdit(self)

        self.large_index_right_edit = QLineEdit(self)
        self.large_middle_right_edit = QLineEdit(self)
        self.large_ring_right_edit = QLineEdit(self)
        
        self.small_index_right_edit = QLineEdit(self)
        self.small_middle_right_edit = QLineEdit(self)
        self.small_ring_right_edit = QLineEdit(self)

        self.grid_layout.addWidget(self.large_index_left_edit, 1 , 2)
        self.grid_layout.addWidget(self.large_middle_left_edit, 1 , 3)
        self.grid_layout.addWidget(self.large_ring_left_edit, 1 , 4)

        self.grid_layout.addWidget(self.small_index_left_edit, 2 , 2)
        self.grid_layout.addWidget(self.small_middle_left_edit, 2 , 3)
        self.grid_layout.addWidget(self.small_ring_left_edit, 2 , 4)

        self.grid_layout.addWidget(self.large_index_right_edit, 3 , 2)
        self.grid_layout.addWidget(self.large_middle_right_edit, 3 , 3)
        self.grid_layout.addWidget(self.large_ring_right_edit, 3, 4)

        self.grid_layout.addWidget(self.small_index_right_edit, 4 , 2)
        self.grid_layout.addWidget(self.small_middle_right_edit, 4 , 3)
        self.grid_layout.addWidget(self.small_ring_right_edit, 4, 4)

        
        self.grid_layout.addWidget(self.empty_label, 5, 2, 1, 3)


        # Create a QPushButton to save the values
        self.submit_button = QPushButton('SUBMIT', self)
        self.submit_button.setFont(font_submit)
        self.submit_button.clicked.connect(self.SubmitData)
        self.submit_button.setStyleSheet('background-color: lightgray;')
        self.grid_layout.addWidget(self.submit_button, 6, 2, 1, 3)

        self.setLayout(self.grid_layout)


        self.show()

    def SubmitData(self):
        self.submit_button.setEnabled(False)

        self.thimbles_values = []
        rows = [1,2,3,4]
        columns =[2,3,4]
        for col in columns:
            col_values = []
            for row in rows:
                line_edit = self.grid_layout.itemAtPosition(row, col).widget()
                value_text = line_edit.text()
                col_values.append(value_text)
            self.thimbles_values.append(col_values)
        self.close()

        return self.thimbles_values
        


