## Libraries
import pandas as pd
from datetime import datetime
import socket
import time
from FUNC_GUI import OpenGuiCalibration
from FUNC import CleanTerminal, ClosePrompts, RunNewPrompt, SetActuationPoints, GenerateCommand


def ForceCalibration(path_subj_folder, filename_prompt_csharp, path_prompt_csharp):

    CleanTerminal()
    print("\nFORCE CALIBRATION\n")



    ###### FILENAME AND SHEET NAME ####################################################
    ## Filename
    filename_xlsx_familiarization = "_xlsx_familiarization.xlsx" 
    filename_xlsx_force = "_xlsx_thimble_basal.xlsx" 
    filename_xlsx_triggers = "_xlsx_triggers_dict.xlsx"
    
    ## Sheets name
    sheet_familiarization = "Familiarization"  
    sheet_time = "Timetable"
    sheet_force = "Basal Forces" 



    ###### TRIGGER DATA FRAME ####################################################
    ## Extract trigger dictionary from txt file
    df_trigger = pd.DataFrame()
    df_trigger = pd.read_excel(f"{path_subj_folder}\{filename_xlsx_triggers}")

    ## Extract triggers 
    trigger_start = df_trigger['Trigger'].loc[df_trigger['Trigger name'] == 'Start Experiment'].iloc[0].tolist()
    trigger_stop = df_trigger['Trigger'].loc[df_trigger['Trigger name'] == 'Stop Experiment'].iloc[0].tolist()
    trigger_cue = df_trigger['Trigger'].loc[df_trigger['Trigger name'] == 'Cue'].iloc[0].tolist()
    trigger_pause = df_trigger['Trigger'].loc[df_trigger['Trigger name'] == 'Pause'].iloc[0].tolist()
    trigger_stim = df_trigger['Trigger'].loc[df_trigger['Trigger name'] == 'Stimulation'].iloc[0].tolist() 
    trigger_break = df_trigger['Trigger'].loc[df_trigger['Trigger name'] == 'Break'].iloc[0].tolist() 
    

    
    
    ###### FAMILIARIZATION DATA FRAME ####################################################
    ## Upload familiarization file as a dataframe
    path_xlsx_familiarization = f'{path_subj_folder}\{filename_xlsx_familiarization}'   
    df_familiarzation = pd.read_excel(path_xlsx_familiarization, sheet_familiarization)

    ## Extract commands from familiarization dataframe 
    last_column = df_familiarzation.shape[1]

    ## Break
    cmd_break = df_familiarzation.loc[df_familiarzation['Stimulation type'] == 'Break'].iloc[0, 2:df_familiarzation.shape[1]].tolist()
    cmd_str_break = GenerateCommand(cmd_break, path_subj_folder)
    cmd_str_break = f"cmd : {trigger_break} : {cmd_str_break} : end "

    ## Cue
    cmd_cue = df_familiarzation.loc[df_familiarzation['Stimulation type'] == 'Cue'].iloc[0, 2:df_familiarzation.shape[1]].tolist()
    cmd_str_cue = GenerateCommand(cmd_cue, path_subj_folder)

    ## Pause
    cmd_pause = df_familiarzation.loc[df_familiarzation['Stimulation type'] == 'Pause'].iloc[0, 2:df_familiarzation.shape[1]].tolist()
    cmd_str_pause = GenerateCommand(cmd_pause, path_subj_folder)

    ## Force, low. high frequency
    cmd_force = df_familiarzation.loc[df_familiarzation['Stimulation type'] == 'Force Min'].iloc[0, 1:last_column].tolist()
    cmd_frequency_low = df_familiarzation.loc[df_familiarzation['Stimulation type'] == 'Frequency Low'].iloc[0, 1:last_column].tolist()
    cmd_frequency_high = df_familiarzation.loc[df_familiarzation['Stimulation type'] == 'Frequency High'].iloc[0, 1:last_column].tolist() 

    print(f"\nFamiliarization dataframe: \n\n{df_familiarzation}\n\n")
    
    

    ###### FORCE DATA FRAME ####################################################
    ## Upload basal force file as a dataframe
    path_xlsx_force = f'{path_subj_folder}\{filename_xlsx_force}'
    df_forces = pd.read_excel(path_xlsx_force, sheet_force)

    print(f"\nInitial forces dataframe: \n\n{df_forces}\n\n")

    ## Initialize initial values
    ## Index finger
    force_initial_index_min = df_forces['Index'].loc[df_forces['Force'] == '(R) Min Force'].astype(float).to_list()[0]
    force_initial_index_max = df_forces['Index'].loc[df_forces['Force'] == '(R) Max Force'].astype(float).to_list()[0]
    
    ## Middle finger
    force_initial_middle_min = df_forces['Middle'].loc[df_forces['Force'] == '(R) Min Force'].astype(float).to_list()[0]
    force_initial_middle_max = df_forces['Middle'].loc[df_forces['Force'] == '(R) Max Force'].astype(float).to_list()[0]
   
    ## Ring finger
    force_initial_ring_min = df_forces['Ring'].loc[df_forces['Force'] == '(R) Min Force'].astype(float).to_list()[0]
    force_initial_ring_max = df_forces['Ring'].loc[df_forces['Force'] == '(R) Max Force'].astype(float).to_list()[0]
  
    

    ###### INITIALIZATIONS ####################################################
    ## Set actuation points
    hand = 2                  # Right hand

    ## Set range of the force
    range_force = [0.0, 1.0]
    
    ## Initialize list of force values to be updated  
    ##   Line 0, 1 = MIN, MAX
    ##   Columns 0, 1, 2 = INDEX, MIDDLE, RING
    values_to_change = [[force_initial_index_min, force_initial_middle_min, force_initial_ring_min], 
                        [force_initial_index_max, force_initial_middle_max,  force_initial_ring_max] ]

    update_min_force = values_to_change[0]
    update_max_force = values_to_change[1]
    
    ###### CALIBRATION PART ####################################################
    try:

        ClosePrompts(filename_prompt_csharp)
        RunNewPrompt(path_prompt_csharp)



        ###### TIMESTAMP ####################################################
        start_calibration = datetime.now()

        ## Calculate date and time of the test
        date = f'{str(start_calibration.year)}-{str(start_calibration.month)}-{str(start_calibration.day)}'
        time_test =f'{start_calibration.strftime("%H:%M:%S ")}'


        
        ###### SOCKET ####################################################
        ## Create socket with csharp file
        host, port = "127.0.0.1", 5555
        aClientSocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        aClientSocket.connect((host, port))

        print()

        color_not_selected = "#f9f9c6"
        color_selected = "#cd853f"
        color_light_grey = "#a9a9a9"
        color_dark_grey = "#696969"
        

        
        ###### CALIBRATION ####################################################
        while True:

            ## Send START command to connect the middleware 
            cmd_str_start = f"cmd : {trigger_start} : end "
            print(f'\nSent command <<{cmd_str_start}>>')
            aClientSocket.send(cmd_str_start.encode("utf-8"))
         
            
            ###### SELECT FINGER ####################################################            
            flag_continue = True

            while flag_continue:

                flag_list = [True, True, True, 
                             False, False, False, 
                             False, False]
                
                color_list = [color_not_selected, color_not_selected, color_not_selected,
                              color_not_selected, color_not_selected, color_light_grey,
                              color_not_selected, color_light_grey,
                              color_dark_grey]
            
                # Send BREAK command 
                print(f'            PAUSE - Sent command: <<{cmd_str_break}>>')
                aClientSocket.send(cmd_str_break.encode("utf-8"))

                
                ## Select the finger to work on 
                current_force_label = f"MIN =  {update_min_force[0]}    {update_min_force[1]}    {update_min_force[2]}\nMAX =  {update_max_force[0]}    {update_max_force[1]}    {update_max_force[2]}\n"
                selected_finger = OpenGuiCalibration(flag_list, color_list, current_force_label)
            
                ## For the selected finger:
                ## Define    
                ##   - finger ind [ind_finger]
                ##   - other fingers ind [ind_finger_other]
                ##   - corresponding finger index ind
                ## the finger in the command lists, and corresponding indeces of the other fingers in the command lists
                if selected_finger == "index":
                    ind_finger, ind_finger_others = 0, [1,2]
                    ind_in_list_finger, ind_in_list_others = 2, [3,4]
                    color_list[0] = color_selected
                    color_list[1] = color_not_selected
                    color_list[2] = color_not_selected

                elif selected_finger == "middle":
                    ind_finger, ind_finger_others = 1, [0,2]
                    ind_in_list_finger, ind_in_list_others = 3, [2,4]
                    color_list[1] = color_selected
                    color_list[0] = color_not_selected
                    color_list[2] = color_not_selected

                elif selected_finger == "ring":
                    ind_finger, ind_finger_others = 2, [0,1]
                    ind_in_list_finger, ind_in_list_others = 4, [2,3]
                    color_list[2] = color_selected
                    color_list[0] = color_not_selected
                    color_list[1] = color_not_selected
                elif selected_finger == "close":
                    flag_continue = False
                    break

                ## Print hand and finger   
                strings = SetActuationPoints(hand, ind_finger)
                print(f'\n     |Hand: {strings[0]}\n     |Finger: {strings[1]}')
                   
                ###### SELECT MIN/MAX ####################################################
                
                flag_force = True
                while flag_continue and flag_force:

                    flag_list = [False, False, False, 
                                True, True, True,
                                False, False ]
                    
                
                    ## Send BREAK command 
                    print(f'            PAUSE - Sent command: <<{cmd_str_break}>>')
                    aClientSocket.send(cmd_str_break.encode("utf-8"))
                    
                    ## Select which force to set
                    selected = OpenGuiCalibration(flag_list, color_list, current_force_label)
                     
                    ## For the selected operation:
                    ## Define the line of the force list to be updated
                    if selected == "min":
                        line_to_change = 0
                        color_list[3] = color_selected
                        
                    elif selected== "max":
                        line_to_change = 1
                        color_list[4] = color_selected

                    elif selected == "changefinger":
                        flag_force = False; 
                        color_list[0] = color_not_selected
                        color_list[1] = color_not_selected
                        color_list[2] = color_not_selected
                        color_list[3] = color_not_selected
                        color_list[4] = color_not_selected
                        break

                    elif selected == "close":
                        flag_continue = False; 
                        break

                    ## Update the value in the command list
                    cmd_stim = cmd_force
                    cmd_stim[ind_in_list_finger] = values_to_change[line_to_change][ind_finger]
                    cmd_stim[ind_in_list_others[0]] = values_to_change[line_to_change][ind_finger_others[0]]
                    cmd_stim[ind_in_list_others[1]] = values_to_change[line_to_change][ind_finger_others[1]]
                    
                    print(f'\n            Force = {values_to_change}')




                    ###### SELECT OPERATION ####################################################
                    flag_break = False
                    flag_operation = True
                    selected = None

                    while flag_continue and flag_operation:

                        flag_list = [False, False, False, 
                                    False, False, False,
                                    True, True]
                        
                        # Send BREAK command 
                        print(f'            PAUSE - Sent command: <<{cmd_str_break}>>')
                        aClientSocket.send(cmd_str_break.encode("utf-8"))
                        time.sleep(0.2)


                        ## Send STIMULATION commmand
                        cmd_str_stim = GenerateCommand(cmd_stim[1:len(cmd_stim)], path_subj_folder)
                        command = f"cmd : 0 : 0 : {trigger_stim} : {trigger_stim} : {cmd_str_stim} : {trigger_cue} : {cmd_str_cue} : {trigger_pause} : {cmd_str_pause} : end "
                        aClientSocket.send(command.encode("utf-8"))
                        
                                                
                        if flag_break == True:
                            time.sleep(2)

                            ## Send BREAK command 
                            print(f'            PAUSE - Sent command: <<{cmd_str_break}>>')
                            aClientSocket.send(cmd_str_break.encode("utf-8"))
                            time.sleep(0.2)

                        # cmd_stim = cmd_force
                        # cmd_stim[ind_in_list_finger] = values_to_change[line_to_change][ind_finger]
                        # cmd_stim[ind_in_list_others[0]] = values_to_change[line_to_change][ind_finger_others[0]]
                        # cmd_stim[ind_in_list_others[1]] = values_to_change[line_to_change][ind_finger_others[1]]  
                        # cmd_str_stim = GenerateCommand(cmd_stim[1:len(cmd_stim)], path_subj_folder)
                        # aClientSocket.send(cmd_str_stim.encode("utf-8"))
                            
                                       
                        ## Select the type stimulation
                        current_force_label = f"MIN =  {update_min_force[0]}    {update_min_force[1]}    {update_min_force[2]}\nMAX =  {update_max_force[0]}    {update_max_force[1]}    {update_max_force[2]}\n"
                        selected = OpenGuiCalibration(flag_list, color_list, current_force_label)
                        print(selected)
                       
                        ## For the selected type of stimulation:

                        ## Set the parameters in the command            
                    
                        if selected == "+0.05":  # Increase by 0.05 the last value of force
                            values_to_change[line_to_change][ind_finger] = round( (values_to_change[line_to_change][ind_finger] + 0.05), 2) 
                            ## Check if the new value is inside the range of validity, otherwise set at 1.0    
                            if values_to_change[line_to_change][ind_finger] > range_force[1]:
                                print(f'Value {values_to_change[line_to_change][ind_finger]} out of the valid range {range_force} --> Default = 1.0')
                                values_to_change[line_to_change][ind_finger] = range_force[1]  
                            ## Set values in the stimulation list
                            cmd_stim = cmd_force
                            cmd_stim[ind_in_list_finger] = values_to_change[line_to_change][ind_finger]
                            cmd_stim[ind_in_list_others[0]] = values_to_change[line_to_change][ind_finger_others[0]]
                            cmd_stim[ind_in_list_others[1]] = values_to_change[line_to_change][ind_finger_others[1]]        
                            flag_break = False                         
                            print(f'\n            Force = {values_to_change}')

                                
                        elif selected == "+0.01":  # Increase by 0.01 the last value of force
                            values_to_change[line_to_change][ind_finger] = round( (values_to_change[line_to_change][ind_finger] + 0.01), 2)     
                            ## Check if the new value is inside the range of validity, otherwise set at 1.0    
                            if values_to_change[line_to_change][ind_finger] > range_force[1]:
                                print(f'Value {values_to_change[line_to_change][ind_finger]} out of the valid range {range_force} --> Default = 1.0')
                                values_to_change[line_to_change][ind_finger] = range_force[1]
                            ## Set values in the stimulation list
                            cmd_stim = cmd_force
                            cmd_stim[ind_in_list_finger] = values_to_change[line_to_change][ind_finger]
                            cmd_stim[ind_in_list_others[0]] = values_to_change[line_to_change][ind_finger_others[0]]
                            cmd_stim[ind_in_list_others[1]] = values_to_change[line_to_change][ind_finger_others[1]] 
                            flag_break = False                                    
                            print(f'\n            Force = {values_to_change}') 
     
                        elif selected == "-0.01":  # Decrease by 0.01 the last value of force
                            values_to_change[line_to_change][ind_finger] = round( (values_to_change[line_to_change][ind_finger] - 0.01), 2)     
                            ## Check if the new value is inside the range of validity, otherwise set at 0.0    
                            if values_to_change[line_to_change][ind_finger] < range_force[0]:
                                print(f'Value {values_to_change[line_to_change][ind_finger]} out of the valid range {range_force} --> Default = 0.0')
                                values_to_change[line_to_change][ind_finger] = range_force[0]
                            ## Set values in the stimulation list
                            cmd_stim = cmd_force
                            cmd_stim[ind_in_list_finger] = values_to_change[line_to_change][ind_finger]
                            cmd_stim[ind_in_list_others[0]] = values_to_change[line_to_change][ind_finger_others[0]]
                            cmd_stim[ind_in_list_others[1]] = values_to_change[line_to_change][ind_finger_others[1]]      
                            flag_break = False                               
                            print(f'\n            Force = {values_to_change}') 

                        elif selected ==  "-0.05":  # Decrease by 0.05 the last value of force   
                            values_to_change[line_to_change][ind_finger] = round( (values_to_change[line_to_change][ind_finger] - 0.05), 2)     
                            ## Check if the new value is inside the range of validity, otherwise set at 0.0 
                            if values_to_change[line_to_change][ind_finger] < range_force[0]:
                                print(f'Value {values_to_change[line_to_change][ind_finger]} out of the valid range {range_force} --> Default = 0.0')
                                values_to_change[line_to_change][ind_finger] = range_force[0]
                            ## Set values in the stimulation list
                            cmd_stim = cmd_force
                            cmd_stim[ind_in_list_finger] = values_to_change[line_to_change][ind_finger]
                            cmd_stim[ind_in_list_others[0]] = values_to_change[line_to_change][ind_finger_others[0]]
                            cmd_stim[ind_in_list_others[1]] = values_to_change[line_to_change][ind_finger_others[1]]     
                            flag_break = False                               
                            print(f'\n            Force = {values_to_change}')
                        
                        elif selected == "lowfreq":  # Low vibration
                            ## Set values in the stimulation list
                            cmd_stim = cmd_frequency_low
                            cmd_stim[ind_in_list_finger] = values_to_change[line_to_change][ind_finger]
                            cmd_stim[ind_in_list_others[0]] = values_to_change[line_to_change][ind_finger_others[0]]
                            cmd_stim[ind_in_list_others[1]] = values_to_change[line_to_change][ind_finger_others[1]]
                            flag_break = True 
                            print(f'\n            Vibration = {cmd_stim[6]}') 

                        elif selected == "highfreq":  # High vibration   
                            ## Set values in the stimulation list
                            cmd_stim = cmd_frequency_high
                            cmd_stim[ind_in_list_finger] = values_to_change[line_to_change][ind_finger]
                            cmd_stim[ind_in_list_others[0]] = values_to_change[line_to_change][ind_finger_others[0]]
                            cmd_stim[ind_in_list_others[1]] = values_to_change[line_to_change][ind_finger_others[1]]
                            flag_break = True
                            print(f'\n            Vibration = {cmd_stim[6]}')
                        
                        elif selected == "restore":  # No Vibration
                            ## Set values in the stimulation list
                            cmd_stim = cmd_force
                            cmd_stim[ind_in_list_finger] = values_to_change[line_to_change][ind_finger]
                            cmd_stim[ind_in_list_others[0]] = values_to_change[line_to_change][ind_finger_others[0]]
                            cmd_stim[ind_in_list_others[1]] = values_to_change[line_to_change][ind_finger_others[1]]   
                            flag_break = False                                 
                            print(f'\n            Force = {values_to_change}')
                        
                        elif selected == "changeforce":
                            flag_operation = False; 
                            color_list[3] = color_not_selected
                            color_list[4] = color_not_selected
                            break
                        
                        elif selected == "close":
                            flag_continue = False


                        ###### UPDATES ####################################################
                        ## Update force values
                        update_min_force = values_to_change[0][:]
                        print(f'\n     Selected MIN forces = {update_min_force}')
                        update_max_force = values_to_change[1][:]
                        print(f'     Selected MAX forces = {update_max_force}\n')

            break        
        end_time = datetime.now()  
        


        ###### FORCE DATAFRAME ####################################################
        ## Save updates
        update_min_force = values_to_change[0][:]
        update_max_force = values_to_change[1][:]

        print(f'\nMIN forces = {update_min_force}')
        print(f'Selected MAX forces = {update_max_force}\n')

        df_forces['Index'] = [None, None, update_min_force[0], update_max_force[0]]
        df_forces['Middle'] = [None, None, update_min_force[1], update_max_force[1]]
        df_forces['Ring'] = [None, None, update_min_force[2], update_max_force[2]]

        print(f'\n\nForces:\n{df_forces}')
        

        ###### TIMESTAMP #########################################################
        ## Count time elapsed
        time_difference = end_time - start_calibration
        time_elapsed_min = int(time_difference.total_seconds() // 60)
        time_elapsed_sec = int(time_difference.total_seconds() % 60)

        print(f'Time elapsed: {time_elapsed_min}m : {time_elapsed_sec}s')
        
        ## Save into dataframe
        df_time = pd.DataFrame()
        df_time['Data'] = ['Date', 'Test Time', 'Elapsed Time']
        df_time['Time'] = [date, time_test, f'{time_elapsed_min}m : {time_elapsed_sec}s']

        print(f'\n\nTime:\n {df_time}')
        


        ###### SAVE DATAFRAME #########################################################
        ## Save dataframe into xlsx file
        with pd.ExcelWriter(path_xlsx_force, mode = 'a', engine='openpyxl', if_sheet_exists='overlay') as workbook:    
            df_time.to_excel(workbook, sheet_name = sheet_time, index=False)
            df_forces.to_excel(workbook, sheet_name = sheet_force, index=False)


    finally:
        ## Send START command to connect the middleware 
        cmd_str_stop = f"cmd : {trigger_stop} : end"
        print(f'\nSent command <<{cmd_str_stop}>>')
        aClientSocket.send(cmd_str_stop.encode("utf-8"))

        print("Force calibration DONE")


