from PyQt5 import QtGui
from PyQt5.QtWidgets import QWidget, QLabel, QLineEdit, QVBoxLayout, QPushButton

class SubjectInfo(QWidget):
    def __init__(self):
        super().__init__()
        self.WindowSetup()

    def WindowSetup(self):
        self.setWindowTitle("General Information GUI")
        self.setGeometry(700, 400, 300, 300)

        font = QtGui.QFont()
        font.setPointSize(11)

        self.name_label = QLabel('Name:')
        self.name_label.setFont(font)
        self.name_edit = QLineEdit(self)
        self.name_edit.setFont(font)

        self.surname_label = QLabel('Surname:')
        self.surname_label.setFont(font)
        self.surname_edit = QLineEdit(self)
        self.surname_edit.setFont(font)

        self.gender_label = QLabel('Gender:')
        self.gender_label.setFont(font)
        self.gender_edit = QLineEdit(self)
        self.gender_edit.setFont(font)

        self.date_birth_label = QLabel('Date of birth:')
        self.date_birth_label.setFont(font)
        self.date_birth_edit = QLineEdit(self)
        self.date_birth_edit.setFont(font)

        self.date_experiment_label = QLabel('Date of the experiment:')
        self.date_experiment_label.setFont(font)
        self.date_experiment_edit = QLineEdit(self)
        self.date_experiment_edit.setFont(font)

        self.submit_button = QPushButton('SUBMIT', self)
        self.submit_button.setFont(font)
        self.submit_button.setStyleSheet('background-color: lightgray;')
        self.submit_button.clicked.connect(self.SubmitData)

        self.empty_label = QLabel('')
        self.empty_label.setFont(font)

        layout = QVBoxLayout()
        layout.addWidget(self.name_label)
        layout.addWidget(self.name_edit)
        layout.addWidget(self.surname_label)
        layout.addWidget(self.surname_edit)
        layout.addWidget(self.gender_label)
        layout.addWidget(self.gender_edit)
        layout.addWidget(self.date_birth_label)
        layout.addWidget(self.date_birth_edit)
        layout.addWidget(self.date_experiment_label)
        layout.addWidget(self.date_experiment_edit)
        layout.addWidget(self.empty_label)
        layout.addWidget(self.submit_button)

        self.setLayout(layout)

    def SubmitData(self):
        self.submit_button.setEnabled(False)
        self.name = self.name_edit.text()
        self.surname = self.surname_edit.text()
        self.gender = self.gender_edit.text()
        self.birthday = self.date_birth_edit.text()
        self.age = self.date_experiment_edit.text()
        self.info = [self.name, self.surname, self.gender, self.birthday, self.age]
        self.close()

        return self.info

