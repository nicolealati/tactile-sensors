import sys
import pandas as pd
from PyQt5 import QtCore, QtWidgets, QtGui
from PyQt5.QtWidgets import QWidget, QVBoxLayout, QHBoxLayout, QLabel, QGridLayout, QPushButton, QGroupBox, QRadioButton
from PyQt5.QtGui import QColor
from PyQt5.QtNetwork import QTcpServer, QHostAddress


class InterfacesWindow(QWidget):
    def __init__(self, path_results_xlsx_exp, path_txt_safety_experiment, parameters):
        super(InterfacesWindow, self).__init__()
        
        self.path_results_xlsx_exp = path_results_xlsx_exp
        self.path_txt_safety_experiment = path_txt_safety_experiment
        self.n_reps = parameters[0]
        self.n_block = parameters[1]

        # Set fonts and Create initial gui
        self.DefineFonts()
        self.InitialGUI()

        ## Initiliaze answers
        self.all_ans = "CLASSIFICATION"

        ## Load stimulation dataframe
        self.sheet_stim = "Experiment Sequence"       
        self.sheet_answ = "Answers"   
        self.sheet_pauses = "Required Pauses"  

        self.df_stim = pd.read_excel(path_results_xlsx_exp, self.sheet_stim)
        
        print(self.df_stim)
        print()

        # Creare Tpc server and start listening
        self.CreateStartServer()
        

    def DefineFonts(self):
         # Set label font
        self.font_label = QtGui.QFont()
        self.size_label = 40
        self.size_cross = 150
        self.font_label.setFamily("Segoe UI")
         ## Set groupbox font
        self.font_box = QtGui.QFont()
        self.font_box.setPointSize(17)
        self.font_box.setBold(True)
        self.color_box = "#fbfbfb" 
        ## Set radiobuttons font
        self.font_radio_buttons = QtGui.QFont()
        self.font_radio_buttons.setPointSize(14)
        self.font_radio_buttons.setBold(False)
        ## Set save button font
        self.font_push_button = QtGui.QFont()
        self.font_push_button.setPointSize(16)
        self.font_push_button.setBold(True)
        self.color_push_button = "#cbced4"

    def InitialGUI(self):
        # Creazione della griglia 1x3
        self.grid_layout = QGridLayout()
        # Creare la griglia 9x9
        for i in range(3):
            for j in range(3):
                # self.color = QColor(170, 200, 150)
                # self.grid_layout .addWidget(self.createColoredSquare(), i, j)
                self.grid_layout.addWidget(QWidget(), i, j)
        
        ## LABEL
        # Create vertical box
        self.vertical_layout_label = QVBoxLayout()
        # Create labels
        self.label = QLabel("", alignment=QtCore.Qt.AlignHCenter)  
        self.empty_1 = QLabel("   ")
        self.empty_2 = QLabel("   ")
        # Add labels to vertical layout 
        # self.vertical_layout_label.addWidget(self.empty_1)
        # self.vertical_layout_label.addWidget(self.empty_2)
        self.vertical_layout_label.addWidget(self.label)
        # Add vertical layout to grid layout
        self.grid_layout.addLayout(self.vertical_layout_label, 1, 1)
        
        # Add grid_layout to self
        self.setLayout(self.grid_layout)

    def createColoredSquare(self):
        square = QWidget()
        square.setStyleSheet(f"background-color: {self.color.name()}")
        return square
       
    def CreateStartServer(self): 
        ## Create TCP server
        self.tcp_server = QTcpServer(self)
        self.tcp_server.newConnection.connect(self.HandleConnection)
        # Starting the TCP server on defined port 
        port = 8888
        if self.tcp_server.listen(QHostAddress.LocalHost, port):
            print(f"    TCP server listening on {port} port" )
        else:
            print("     ERROR in starting TCP server on {port} port")
    
    def HandleConnection(self):
        self.client_socket = self.tcp_server.nextPendingConnection()
        self.client_socket.readyRead.connect(lambda: self.SelectOperation(self.client_socket))
    
    def SelectOperation(self, client_socket):
        if client_socket is not None and client_socket.bytesAvailable() > 0:
            # Received message
            self.recv_msg = client_socket.readAll().data().decode('utf-8')
            self.HandleRecvMsg()
            self.msg_back = f"{self.trigger} done"

            ## Operation based on the received message            
            # START
            if self.trigger == "50":
                # Refresh text in the label
                self.label.setText("") 
                self.font_label.setPointSize(self.size_label)
                self.label.setFont(self.font_label)
                # Add button to continue
                self.text_button = "Click to start the experiment"
                self.CreateButton()
                # Delete the button when clicked 
                self.push_button.clicked.connect(self.DeleteButton)


            # END
            elif self.trigger == "51": 

                # Refresh text in the label
                self.label.setText("END")
                self.font_label.setPointSize(self.size_label)
                self.label.setFont(self.font_label)
                # Add button to continue
                self.text_button = "Manually close window "
                self.CreateButton()
                self.push_button.setEnabled(False)
                # Delete the button when clicked 
                self.SendMsgToClient()

                
            # CROSS
            elif self.trigger == "60": 
                # Refresh text in the label
                self.label.setText("+")
                self.font_label.setPointSize(self.size_cross)
                self.label.setFont(self.font_label)
                # Send back msg 
                self.SendMsgToClient()
                
           
            # REST
            elif self.trigger == "61": 
                # Refresh text in the label
                self.label.setText("")              
                # Send back msg 
                self.SendMsgToClient()    


            # BREAK
            elif self.trigger == "62": 
                
                # Refresh text in the label
                self.label.setText("BREAK")
                self.font_label.setPointSize(self.size_label)
                self.label.setFont(self.font_label)
                # Add button to continue
                self.text_button = "Click to continue"
                self.CreateButton()
                # Delete the button when clicked 
                self.push_button.clicked.connect(self.DeleteButton)


            # REQUIRED PAUSE
            elif self.trigger == "63": 
                
                # Refresh text in the label
                f"Block {self.block}/{self.n_block}\nStimulation {self.nstim}/{int(self.n_reps*6/self.n_block)}\n"
                self.label.setText(f"PAUSE\nBlock {self.block}/{self.n_block}\nStimulation {self.nstim}/{int((self.n_reps*6)/self.n_block)}\n\nPress Enter on the keyboard to continue")
                self.font_label.setPointSize(self.size_label)
                self.label.setFont(self.font_label)
                # Load dataframe
                self.df_pauses = pd.read_excel(self.path_results_xlsx_exp, sheet_name=self.sheet_pauses)
                self.df_pauses.loc[self.df_pauses.shape[0],:] = [self.block, self.nstim, self.ncomb]
                with pd.ExcelWriter(self.path_results_xlsx_exp, mode = 'a', engine='openpyxl', if_sheet_exists='overlay') as workbook:
                    self.df_pauses.to_excel(workbook, sheet_name = self.sheet_pauses, index=False)

                # Send back msg 
                self.SendMsgToClient()
            
            # CLASSIFICATION
            elif self.trigger == "90":
                
                # Refresh text in the label
                self.label.setText("")
                # Load dataframe
                self.df_answers = pd.read_excel(self.path_results_xlsx_exp, sheet_name=self.sheet_answ)
                self.df_block = self.df_stim.loc[self.df_stim['Block'] == self.block]
                # Provided force
                self.prov_force = self.df_block.loc[self.df_block['N. Stim'] == self.nstim].iloc[0, 5].tolist()
                if self.prov_force == 1:
                    self.prov_force = " max"
                else: 
                    self.prov_force = " min"
                # Provided frequency
                self.prov_frequency = self.df_block.loc[self.df_block['N. Stim'] == self.nstim ].iloc[0, 9].tolist()

                if self.prov_frequency == 3:
                    self.prov_frequency = " low freq"
                elif self.prov_frequency == 7: 
                    self.prov_frequency = " high freq"
                else: 
                    self.prov_frequency = " without vibr"
                self.CreateClassificationGroupbox()

            
            # WRONG MSG
            else:
                # Send back msg 
                self.SendMsgToClient()

    def HandleRecvMsg(self):
        # Consider only numeric chars and join them, replace spaces
        print(f"\n\nComplete msg = {self.recv_msg}")
        numeric_chars = [char for char in self.recv_msg if char.isdigit()]
        numeric_msg = ''.join(numeric_chars)
        numeric_msg = numeric_msg.replace(" ", "")
        
        # Consider only first two chars
        self.trigger = numeric_msg[0:2]
        print(f"Trigger: {self.trigger}, length: {len(self.trigger)}")
        for char in self.trigger:
            print(f"        c = {char}")

        # Define classification parameters to be saved in the dataframe
        if len(numeric_msg)>2:
            self.block = int(numeric_msg[2])
            if len(numeric_msg) == 7:
                self.nstim = int(numeric_msg[3:5])
                self.ncomb = int(numeric_msg[6])
            else:
                self.nstim = int(numeric_msg[3])
                self.ncomb = int(numeric_msg[5])

            print(f"# trigger = {self.trigger}")
            print(f"# block = {self.block}")
            print(f"# stim = {self.nstim}")
            print(f"# comb = {self.ncomb}")

    def CreateButton(self): 
        ## Create push_botton
        self.vertical_layout_push_button = QVBoxLayout()
        self.push_button = QPushButton(self.text_button)
        self.push_button.setStyleSheet(f'background-color: {self.color_push_button}') 
        self.push_button.setFont(self.font_push_button)
        # Add btn to grid_layout in riga 3, colonna 2
        self.vertical_layout_push_button.addWidget(self.push_button)
        self.vertical_layout_push_button.addWidget(self.empty_1)
        # Add vertical layout to grid layout
        self.grid_layout.addLayout(self.vertical_layout_push_button, 2, 1)

    def DeleteButton(self):
        self.label.setText("")
        self.push_button.setEnabled(False)
        self.push_button.deleteLater()
        # Send back msg 
        self.SendMsgToClient()

    def CreateClassificationGroupbox(self):  
        ## LABEL
        # Create vertical box
        self.vertical_layout_label_class = QVBoxLayout()
        # Create labels
        self.label_class = QLabel(f"\n\nCLASSIFICATION", alignment=QtCore.Qt.AlignHCenter)
        self.font_label.setPointSize(self.size_label)
        self.label_class.setFont(self.font_label) 
        self.label_block = QLabel(f"Block {self.block}/{self.n_block}\nStimulation {self.nstim}/{int(self.n_reps*6/self.n_block)}\n", alignment=QtCore.Qt.AlignHCenter)
        self.font_label.setPointSize(20)
        self.label_block.setFont(self.font_label) 
        # Add labels to vertical layout 
        self.vertical_layout_label_class.addWidget(self.label_class)
        self.vertical_layout_label_class.addWidget(self.label_block)
        # Add vertical layout to grid
        self.grid_layout.addLayout(self.vertical_layout_label_class, 0, 1)

        ## GROUPBOXES
        # Create horizontal layout for groupbox
        self.hor_layout_groupboxes = QHBoxLayout()
        # Create groupboxes
        self.groupbox_force = QGroupBox("Force")
        self.groupbox_frequency = QGroupBox("Frequency")
        # Set font for groupboxes
        self.groupbox_force.setFont(self.font_box)
        self.groupbox_frequency.setFont(self.font_box)
        # Create vertical layout for radio buttons
        self.vbox_layout_rbtn_force = QVBoxLayout()
        self.vbox_layout_rbtn_frequency = QVBoxLayout()
        # Create radio buttons
        self.rbtn_min_force = QRadioButton(" min")
        self.rbtn_max_force = QRadioButton(" max")
        self.rbtn_force_dontknow = QRadioButton(" I don't know")
        self.rbtn_null = QRadioButton(" ")
        self.rbtn_zero_frequency = QRadioButton(" without vibr")
        self.rbtn_low_frequency = QRadioButton(" low freq")
        self.rbtn_high_frequency = QRadioButton(" high freq")
        self.rbtn_frequency_dontknow = QRadioButton(" I don't know")
        # Set font for radio buttons
        self.rbtn_min_force.setFont(self.font_radio_buttons)
        self.rbtn_max_force.setFont(self.font_radio_buttons)
        self.rbtn_force_dontknow.setFont(self.font_radio_buttons)
        self.rbtn_null.setFont(self.font_radio_buttons)
        self.rbtn_zero_frequency.setFont(self.font_radio_buttons)
        self.rbtn_low_frequency.setFont(self.font_radio_buttons)
        self.rbtn_high_frequency.setFont(self.font_radio_buttons)
        self.rbtn_frequency_dontknow.setFont(self.font_radio_buttons)
        # Set colors for radio buttons
        self.rbtn_min_force.setStyleSheet(f'background-color:{self.color_box};')
        self.rbtn_max_force.setStyleSheet(f'background-color:{self.color_box};')
        self.rbtn_force_dontknow.setStyleSheet(f'background-color:{self.color_box};')
        self.rbtn_null.setStyleSheet(f'background-color: transparent;')
        self.rbtn_zero_frequency.setStyleSheet(f'background-color:{self.color_box};')
        self.rbtn_low_frequency.setStyleSheet(f'background-color:{self.color_box};')
        self.rbtn_high_frequency.setStyleSheet(f'background-color:{self.color_box};')   
        self.rbtn_frequency_dontknow.setStyleSheet(f'background-color:{self.color_box};')  

        # Add radio buttons to force layout
        self.vbox_layout_rbtn_force.addWidget(self.rbtn_min_force)
        self.vbox_layout_rbtn_force.addWidget(self.rbtn_max_force)
        self.vbox_layout_rbtn_force.addWidget(self.rbtn_force_dontknow)
        self.vbox_layout_rbtn_force.addWidget(self.rbtn_null)

        # Add radio buttons to frequency layout
        self.vbox_layout_rbtn_frequency.addWidget(self.rbtn_zero_frequency)
        self.vbox_layout_rbtn_frequency.addWidget(self.rbtn_low_frequency)
        self.vbox_layout_rbtn_frequency.addWidget(self.rbtn_high_frequency)
        self.vbox_layout_rbtn_frequency.addWidget(self.rbtn_frequency_dontknow)

        # Add force layout to force groupbox
        self.groupbox_force.setLayout(self.vbox_layout_rbtn_force)
        self.groupbox_frequency.setLayout(self.vbox_layout_rbtn_frequency)
        
        # Add groupboxes to groupboxes horizontal layout
        self.hor_layout_groupboxes.addWidget(self.groupbox_force)
        self.hor_layout_groupboxes.addWidget(self.groupbox_frequency)

        self.all_vertical_layout = QVBoxLayout()
        self.all_vertical_layout.addWidget(self.empty_1)
        self.all_vertical_layout.addLayout(self.hor_layout_groupboxes)

        

        # Add groupboxes horizontal layout to grid layout
        self.grid_layout.addLayout(self.all_vertical_layout, 1, 1)

        self.text_button = "SAVE"
        self.CreateButton()
        self.push_button.clicked.connect(self.SaveAnswers)

    def SaveAnswers(self):
        self.push_button.setEnabled(False)

        self.perc_force = None
        self.perc_frequency = None

        for radio_button in self.groupbox_force.findChildren(QtWidgets.QRadioButton): 
           if radio_button.isChecked(): 
                self.perc_force = radio_button.text()
                break
        for radio_button in self.groupbox_frequency.findChildren(QtWidgets.QRadioButton): 
           if radio_button.isChecked(): 
                self.perc_frequency = radio_button.text()
                break
        
        # Check correctness of answers
        if self.perc_force == self.prov_force:
            self.corr_force = None
        else: 
            self.corr_force = "ERROR"

        if self.perc_frequency == self.prov_frequency:
            self.corr_frequency = None
        else: 
            self.corr_frequency = "ERROR"
        
        if  self.corr_force == "ERROR" or self.corr_frequency == "ERROR": 
            self.corr_comb = "WRONG"
        else:
            self.corr_comb = None

        new_line = [self.block, self.nstim, self.ncomb, 
                    self.prov_force, self.perc_force, self.corr_force, 
                    self.prov_frequency, self.perc_frequency, self.corr_frequency, 
                    self.corr_comb ]
        self.df_answers.loc[self.df_answers.shape[0],:] = new_line
        print(self.df_answers)

        with pd.ExcelWriter(self.path_results_xlsx_exp, mode = 'a', engine='openpyxl', if_sheet_exists='overlay') as workbook:
            self.df_answers.to_excel(workbook, sheet_name = self.sheet_answ, index=False)

        self.all_ans = str(self.all_ans) + "\n" + str(new_line)
        

        # Open the file in write mode
        with open(self.path_txt_safety_experiment, 'w') as file:
            file.write(str(self.all_ans) + "\n")

        self.label_class.deleteLater()
        self.label_block.deleteLater()
        self.groupbox_force.deleteLater()
        self.groupbox_frequency.deleteLater()
        self.push_button.deleteLater()

        self.SendMsgToClient()

    def SendMsgToClient(self):
        self.client_socket.write((self.msg_back).encode('utf-8'))
        self.client_socket.flush()
    
    def CloseConnection(self):
        if hasattr(self, 'client_socket'):
            self.client_socket.close()
            # Optionally, clean up any resources related to the connection
            del self.client_socket  # Remove the reference to the closed socket
        
        self.ExitProgram()

    def ExitProgram(error): 
        sys.exit("\nExiting")
    
       

