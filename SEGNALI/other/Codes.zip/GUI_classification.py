## AnswersFromGUI HAUWEI

## Libraries
from PyQt5 import QtGui, QtCore
from PyQt5.QtWidgets import QWidget, QVBoxLayout, QHBoxLayout, QGroupBox, QPushButton, QRadioButton, QLabel

class ClassificationWindow(QWidget): 

    def __init__(self, n_stim):
        super().__init__()
        self.n_stim = n_stim
        self.WindowSetup()
    
    def WindowSetup(self):
        self.setWindowTitle('Familiarization + Classification GUI')
        self.setGeometry(700, 400, 550, 400)

        font_label = QtGui.QFont()
        font_label.setPointSize(11)
        font_label.setBold(True)

        font_groupbox = QtGui.QFont()
        font_groupbox.setPointSize(16)
        font_groupbox.setBold(True)

        font_button = QtGui.QFont()
        font_button.setPointSize(16)
        font_button.setBold(False)

        font_save = QtGui.QFont()
        font_save.setPointSize(15)
        font_save.setBold(False)

        x = 30 
        y_button_1, y_button_2, y_button_3, y_button_4 = 60, 110, 160, 210
        width, height  = 260, 40


        ## LABEL for classification
        self.nstim_button = QPushButton(self.n_stim)
        self.nstim_button.setFont(font_label)
        self.nstim_button.setEnabled(False)

        ## FORCE Groupbox
        self.groupbox_force = QGroupBox("Force")
        self.groupbox_force.setFont(font_groupbox)

        self.min_button = QRadioButton(self.groupbox_force)
        self.min_button.setGeometry(QtCore.QRect(x, y_button_1, width, height))
        self.min_button.setText(" min")
        self.min_button.setFont(font_button)

        self.max_button = QRadioButton(self.groupbox_force)
        self.max_button.setGeometry(QtCore.QRect(x, y_button_2, width, height))
        self.max_button.setText(" max")
        self.max_button.setFont(font_button)

        self.null_force = QRadioButton(self.groupbox_force)
        self.null_force.setGeometry(QtCore.QRect(x, y_button_3, width, height))
        self.null_force.setText(" I don't know")
        self.null_force.setFont(font_button)

        ## FREQUENCY Groupbox
        self.groupbox_frequency = QGroupBox("Vibration")
        self.groupbox_frequency.setFont(font_groupbox)

        self.no_freq_button = QRadioButton(self.groupbox_frequency)
        self.no_freq_button.setGeometry(QtCore.QRect(x, y_button_1, width, height))
        self.no_freq_button.setText(" without vibr")
        self.no_freq_button.setFont(font_button)

        self.low_freq_button = QRadioButton(self.groupbox_frequency)
        self.low_freq_button.setGeometry(QtCore.QRect(x, y_button_2, width, height))
        self.low_freq_button.setText(" low freq")
        self.low_freq_button.setFont(font_button)

        self.high_freq_button = QRadioButton(self.groupbox_frequency)
        self.high_freq_button.setGeometry(QtCore.QRect(x, y_button_3, width, height))
        self.high_freq_button.setText(" high freq")
        self.high_freq_button.setFont(font_button)

        self.null_frequency = QRadioButton(self.groupbox_frequency)
        self.null_frequency.setGeometry(QtCore.QRect(x, y_button_4, width, height))
        self.null_frequency.setText(" I don't know")
        self.null_frequency.setFont(font_button)

        self.gb_layout = QHBoxLayout()
        self.gb_layout.addWidget(self.groupbox_force)
        self.gb_layout.addWidget(self.groupbox_frequency)

        ## Save botton
        self.save_button = QPushButton("SAVE", self)
        self.save_button.setFont(font_save)
        self.save_button.setStyleSheet('background-color: lightgrey;')
        self.save_button.clicked.connect(self.SaveAnswers)

        layout = QVBoxLayout()
        layout.addWidget(self.nstim_button)
        layout.addLayout(self.gb_layout)
        layout.addWidget(self.save_button)

        self.setLayout(layout)


    def SaveAnswers(self):
        self.ans_list = [None, None]
         
        for radio_botton in self.groupbox_force.findChildren(QRadioButton): 
            if radio_botton.isChecked(): 
                self.ans_list[0] = radio_botton.text()
                break
            
            if self.ans_list[0] == 0:
                self.ans_list[0] = ''
        
        
        for radio_botton in self.groupbox_frequency.findChildren(QRadioButton): 
            
            if radio_botton.isChecked(): 
                self.ans_list[1] = radio_botton.text()
                break
            
            if self.ans_list[1] == 0:
               self.ans_list[1] = ''

        self.save_button.setEnabled(False)
        print(f'\n{self.ans_list}')
        self.close()

    










        
  




    










        
  


