﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WeArt.Components;
using WeArt.Core;

namespace EXP_csharp
{
    public class EXP_class_TOUCH_DIVER
    {
        private WeArtClient weArtClient;
        private WeArtHapticObject[] hapticFingers;
        private TouchEffect[] effects;

        public EXP_class_TOUCH_DIVER()
        {
            WeArtController weArtController = new WeArtController();
            weArtClient = weArtController.Client;

            // Instantiate haptic objects and haptic effects for each finger
            hapticFingers = new WeArtHapticObject[3];
            effects = new TouchEffect[3];

            for (int i = 0; i < 3; i++)
            {
                hapticFingers[i] = new(weArtClient)
                {
                    HandSides = HandSideFlags.Right,
                    ActuationPoints = (ActuationPointFlags)(1 << i)
                };
                effects[i] = new();
            }

            Console.WriteLine("\n-------------------------------------------------------------------------------\n");
            Console.WriteLine("MiddleWare CONNECTION");

            do
            {
                try
                {
                    Console.WriteLine("Attempting connection to WeArt middleware...");
                    weArtClient.Start();
                }
                catch (Exception e) { Console.WriteLine($"Connection FAILED: {e}\n"); }

                Thread.Sleep(1);
                if (weArtClient.IsConnected)
                    Console.WriteLine($"CONNECTED to WeArt middleware at {weArtClient.IpAddress}, port {weArtClient.Port}\n");
            } while (!weArtClient.IsConnected);
        }

        private void SetEffect(TouchEffect effect,
                     float? forceVal = null,
                     float? tempVal = null,
                     float? textureTypeIdx = null,
                     float? textureVelo = null,
                     float? textureVol = null)
        {
            //// Force component
            Force force = Force.Default;    // Default = 0
            force.Value = forceVal.Value;
            force.Active = true;

            ////Temperature component
            Temperature temperature = Temperature.Default;  // Default = ambient temperature (0.5)
            temperature.Value = tempVal.Value;
            temperature.Active = true;


            //// Vibration component
            Texture texture = Texture.Default;  // Default TextureType 0, Velocity 0
            texture.TextureType = (TextureType)textureTypeIdx;
            texture.Velocity = textureVelo.Value;
            texture.Volume = textureVol.Value;
            texture.Active = true;

            // Apply properties to effect object
            effect.Set(temperature, force, texture);
        }


        // Applies to each actuation point (finger) its respective effect, for the specified duration
        public void SendActuationAsync(
            float duration = 1,
            float[]? force = null,
            float? temperature = null,
            float? type = null,
            float? velocity = null,
            float? volume = null)
        {
            /*
            Console.WriteLine("     |\n     | Duration = " + duration + "\n     | ");
            Console.WriteLine("     | Force = [" + force[0] + ", " + force[1] + ", " + force[2] + "]\n     |");
            Console.WriteLine("     | Temperature = " + temperature.Value + "\n     | ");
            Console.WriteLine("     | Vibration ");
            Console.WriteLine("     |       Type = " + type);
            Console.WriteLine("     |       Velocity = " + velocity);
            Console.WriteLine("     |       Volume = " + volume + "\n");
            */

            for (int i = 0; i < 3; i++)
            {
                // Set effect properties and add to haptic object
                SetEffect(effects[i], force[i], temperature, type, velocity, volume);
                hapticFingers[i].AddEffect(effects[i]);

                //RemoveAllEffects();
            }

        }

        //////// Remove existing effects
        public void RemoveAllEffects()
        {
            for (int i = 0; i < 3; i++)
            {
                if (hapticFingers[i].ActiveEffect != null)
                {
                    hapticFingers[i].RemoveEffect(hapticFingers[i].ActiveEffect);
                }
            }
        }

        //////// Close WeArt socket
        public void CloseWeArtSocket()
        {
            Console.WriteLine("\n\nDisconnecting...");
            weArtClient.Stop();
            Console.WriteLine("DISCONNECTED from WeArt middleware ");
        }


    }
}