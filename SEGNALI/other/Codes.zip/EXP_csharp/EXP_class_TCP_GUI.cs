﻿using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Ports;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;

namespace EXP_csharp
{
    public class EXP_class_TCP_GUI
    {
        private TcpClient client_gui;
        private string str_print = "(TCP_GUI) ";

        public EXP_class_TCP_GUI(string tcp_host_gui, int tcp_port_gui)
        {
            try
            {
                Console.WriteLine($"\n{str_print}Creating client at port {tcp_port_gui}");
                //IPAddress ip_address = IPAddress.Any;
                //IPEndPoint local_end_point = new IPEndPoint(ip_address, tcp_port_gui);
                client_gui = new(tcp_host_gui, tcp_port_gui);
                Console.WriteLine($"{str_print}Client created\n"); 
            }
            catch (Exception e) 
            {
                Console.WriteLine($"{str_print}Error: {e.Message}");
            }  
        }

        public NetworkStream ClientGetStream()
        {
            Console.WriteLine($"\n{str_print}ClientGetStream");
            NetworkStream stream_gui = client_gui.GetStream();
            Console.WriteLine($"{str_print}ClientGetStream done\n");

            return stream_gui;
        }


        public StreamWriter ClientWriter(NetworkStream stream_gui)
        {
            Console.WriteLine($"\n{str_print}ClientWriter");
            StreamWriter writer_gui = new StreamWriter(stream_gui, Encoding.UTF8);
            Console.WriteLine($"{str_print}ClientWriter done\n");

            return writer_gui;
        }
 
        public void CloseTcpConnection(bool listening_flag, int tcp_port)
        {
            if (listening_flag)
            {
                Console.WriteLine($"\n{str_print}Disconnecting port {tcp_port} ");
                client_gui.Close();
                Console.WriteLine($"{str_print}Disconnected\n");
            }
        }
    }
}
