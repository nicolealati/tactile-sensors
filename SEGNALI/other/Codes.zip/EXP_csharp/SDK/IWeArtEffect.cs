//WEART - Effect interface (https://www.weart.it/)

using System;

namespace WeArt.Core
{
    // An interface for objects that combines temperature, force and texture haptic feelings.
    public interface IWeArtEffect
    {
        // The temperature applied by this haptic effect
        Temperature Temperature { get; }

        // The force applied by this haptic effect
        Force Force { get; }

        // The texture applied by this haptic effect
        Texture Texture { get; }

        // This event should be called whenever any of the haptic values changes over time
        event Action OnUpdate;
    }
}