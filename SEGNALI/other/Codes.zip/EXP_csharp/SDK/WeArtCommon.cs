// WeArt - Common utility (https://www.weart.it/)

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Reflection;

namespace WeArt.Core
{
    // The hand side, left or right
    public enum HandSide
    {
        Left = 0,
        Right = 1
    };

    // The multi-selectable version of <see cref="HandSide"/>
    [Flags]
    public enum HandSideFlags
    {
        None = 0,
        Left = 1 << HandSide.Left,
        Right = 1 << HandSide.Right
    };

    // The point of application of the haptic feeling
    public enum ActuationPoint
    {
        Thumb = 0,
        Index = 1,
        Middle = 2,
        Palm = 3,
    };

    // Type of tracking method and messages used/sent by the middleware
    public enum TrackingType
    {
        // Default tracking type, only closures (for right/left thumb/index/middle/palm)
        [Description("")]
        DEFAULT = 0,

        // Closure values for fingers, and thumb abduction value
        [Description("TrackType1")]
        WEART_HAND,
    }

    // Contains extension and util methods for the TrackingType enum.
    public static class TrackingTypeExtension
    {
        // Serializes the trackingtype enum by outputting its description
        /// <param name="type">Enum value to serialize</param>
        /// <returns>enum value serialized to string</returns>
        public static string Serialize(this TrackingType type)
        {
            return type.GetDescription();
        }

        // Deserializes the trackingtype enum value from a given string, based on the type description
        /// <param name="str">String to deserialize into TrackingType</param>
        /// <returns>the deserialized TrackingType value</returns>
        public static TrackingType Deserialize(string str)
        {
            return Enum.GetValues(typeof(TrackingType))
                .Cast<TrackingType>()
                .FirstOrDefault(t => t.GetDescription() == str);
        }

        /// Get the value of the Description attribute for the given Tracking Type value
        /// <param name="value">Tracking Type value from which to get the description</param>
        /// <returns>tracking type value description, or empty string otherwise</returns>
        public static string GetDescription(this TrackingType value)
        {
            Type genericEnumType = value.GetType();
            MemberInfo[] memberInfo = genericEnumType.GetMember(value.ToString());
            if ((memberInfo != null && memberInfo.Length > 0))
            {
                var _Attribs = memberInfo[0].GetCustomAttributes(typeof(System.ComponentModel.DescriptionAttribute), false);
                if ((_Attribs != null && _Attribs.Any()))
                {
                    return ((DescriptionAttribute)_Attribs.ElementAt(0)).Description;
                }
            }
            return "";
        }
    }

    // The multi-selectable version of <see cref="ActuationPoint"/>
    [Flags]
    public enum ActuationPointFlags
    {
        None = 0,
        Thumb = 1 << ActuationPoint.Thumb,
        Index = 1 << ActuationPoint.Index,
        Middle = 1 << ActuationPoint.Middle,
        Palm = 1 << ActuationPoint.Palm,
    };

    // Texture type to Haptic feel
    public enum TextureType : int
    {
        ClickNormal = 0, 
        ClickSoft = 1, 
        DoubleClick = 2,
        AluminiumFineMeshSlow = 3, 
        AluminiumFineMeshFast = 4,
        PlasticMeshSlow = 5, 
        ProfiledAluminiumMeshMedium = 6, 
        ProfiledAluminiumMeshFast = 7,
        RhombAluminiumMeshMedium = 8,
        TextileMeshMedium = 9,
        CrushedRock = 10,
        VenetianGranite = 11,
        SilverOak = 12,
        LaminatedWood = 13,
        ProfiledRubberSlow = 14,
        VelcroHooks = 15,
        VelcroLoops = 16,
        PlasticFoil = 17,
        Leather = 18,
        Cotton = 19,
        Aluminium = 20,
        DoubleSidedTape = 21, 
        
        //  No indexes
        no_vibr22 = 22, 
        no_vibr23 = 23, 
        no_vibr24 = 24, 
        no_vibr25 = 25, 
        no_vibr26 = 26,
        no_vibr27 = 27,
        no_vibr28 = 28,
        no_vibr29 = 29,
        no_vibr30 = 30,
        no_vibr31 = 31,
        no_vibr32 = 32,
        no_vibr33 = 33,
        no_vibr34 = 34,
      
        // New indeces
        n35 = 35,
        n36 = 36,
        n37 = 37, 
        n38 = 38, 
        n39 = 39,
        n40 = 40, 
        n41 = 41, 
        n42 = 42, 
        n43 = 43, 
        n44 = 44, 
        n45 = 45, 
        n46 = 46, 
        n47 = 47, 
        n48 = 48, 
        n49 = 49,
        n50 = 50, 
        n51 = 51, 
        n52 = 52, 
        n53 = 53, 
        n54 = 54, 
        n55 = 55
    }

    // Enum Hand Closing State
    public enum HandClosingState
    {
        Open = 0,
        Closing = 1,
        Closed = 2
    }

    // State of Hand Grasping
    public enum GraspingState
    {
        Grabbed = 0,
        Released = 1
    }

    // Status of the current calibration procedure
    public enum CalibrationStatus
    {
        IDLE = 0,
        Calibrating = 1,
        Running = 2,
    };
    
    public static class WeArtUtility
    {
        // Normalized value from compute dinamic grasp between GraspForce and 1
        public static float NormalizedGraspForceValue(float value)
        {
            return Math.Clamp(value, WeArtConstants.graspForce, 1.0f);
        }
    }

    // Constants shared by the WeArt components
    public static class WeArtConstants
    {
        public const string ipLocalHost = "127.0.0.1";
        public const string WEART_SDK_TYPE = "SdkLLCSH";
        public const string WEART_SDK_VERSION = "1.1.1";

        public const float defaultTemperature = 0.5f;
        public const float minTemperature = 0f;
        public const float maxTemperature = 1f;

        public const float defaultForce = 0f;
        public const float minForce = 0f;
        public const float maxForce = 1f;

        public const float defaultAbduction = 0.442f;
        public const float minAbduction = 0f;
        public const float maxAbduction = 1f;

        public const float defaultClosure = 0f;
        public const float minClosure = 0f;
        public const float maxClosure = 1f;

        public const int defaultTextureIndex = (int)TextureType.ClickNormal;
        public const int minTextureIndex1 = (int)TextureType.ClickNormal;
        public const int maxTextureIndex1 = (int)TextureType.DoubleSidedTape;
        public const int minTextureIndex2 = (int)TextureType.n35;
        public const int maxTextureIndex2 = (int)TextureType.n55;
        public const int nullTextureIndex = 255;

        public const float defaultTextureVelocity = 0.0f;
        public const float minTextureVelocity = 0f;
        public const float maxTextureVelocity = 0.5f;

        public const float defaultCollisionMultiplier = 20.0f;
        public const float minCollisionMultiplier = 0f;
        public const float maxCollisionMultiplier = 100f;

        public const float defaultVolumeTexture = 100.0f;
        public const float minVolumeTexture = 0.0f;
        public const float maxVolumeTexture = 100.0f;

        public const float thresholdThumbClosure = 0.5f;
        public const float thresholdIndexClosure = 0.5f;
        public const float thresholdMiddleClosure = 0.5f;

        public const float graspForce = 0.3f;
        public const float dinamicForceSensibility = 10.0f;


        public static readonly IReadOnlyList<HandSide> HandSides = Enum.GetValues(typeof(HandSide))
            .Cast<HandSide>()
            .ToList();

        public static readonly IReadOnlyList<ActuationPoint> ActuationPoints = Enum.GetValues(typeof(ActuationPoint))
            .Cast<ActuationPoint>()
            .ToList();
    }

}