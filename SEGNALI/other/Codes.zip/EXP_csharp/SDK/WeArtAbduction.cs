// WEaRT - Abduction Value https://www.weart.it/)

using System;

namespace WeArt.Core
{
    // The actuation point abduction amount.
    // It is minimum when the actuation point is far from the hand, maximum when close.
    [Serializable]
    public struct Abduction
    {
        // The default abduction is zero
        public static Abduction Default = new Abduction
        {
            Value = WeArtConstants.defaultAbduction
        };

        internal float _value;

        // The abduction amount, normalized between 0 (max) and 1 (max)
        public float Value
        {
            get => _value;
            set => _value = Math.Max(WeArtConstants.minAbduction, Math.Min(value, WeArtConstants.maxAbduction));
        }
    }
}