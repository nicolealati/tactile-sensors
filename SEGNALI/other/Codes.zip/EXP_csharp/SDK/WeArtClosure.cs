// WeArt - Clousure Force (https://www.weart.it/)

using System;

namespace WeArt.Core
{
    // The actuation point closure amount.
    // It is minimum when the actuation point is open, maximum when closed.
    [Serializable]
    public struct Closure
    {
        // The default closure is zero (max openness)
        public static Closure Default = new Closure
        {
            Value = WeArtConstants.defaultClosure
        };

        internal float _value;
        // The closure amount, normalized between 0 (max openness) and 1 (max closure)
        public float Value
        {
            get => _value;
            set => _value = value;
        }
    }
}