// WeArt - Log utility  (https://www.weart.it/)

using System.Collections.Generic;
using System.IO;
using System.Runtime.CompilerServices;
using System.Diagnostics;

namespace WeArt.Utils
{
    // Utility class used to log events and messages in the <see cref="WeArt"/> framework
    public static class WeArtLog
    {
        // Logs a message in the debug console</summary>
        /// <param name="message">The string message</param>
        /// <param name="callerPath">The path of the caller (optional)</param>
        public static void Log(object message)
        {
            Debug.WriteLine(message);
        }
    }
}