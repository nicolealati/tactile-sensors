﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Concurrent;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;
using EXP_csharp;
using WeArt.Core;
using System.Runtime.InteropServices;
using CommandLine;



public class EXP_MAIN
{
    public class Options
    {

        [Option("port", Default = "4")]
        public string arduino_port { get; set; }

        [Option("diver", Default = true)]
        public bool use_diver { get; set; }

        [Option("trigger", Default = true)]
        public bool send_trigger { get; set; }
    }


    // TO MODIFY
    static string str_print = "(MAIN) ";

    static EXP_class_TCP_COMMUNICATION handler_tcp_comm;
    static EXP_class_TCP_GUI handler_tcp_gui;
    static EXP_class_HANDLE_COMMUNICATION handler_comm_thread;
    static EXP_class_HANDLE_STIMULATION handler_stim_thread;


    // TCP CONNECTIONS
    static string tcp_host = "127.0.0.1"; 
    static int tcp_comm_port = 5_555;
    static int tcp_gui_port = 8_888;
    static bool stop_comm_flag = false;
    static bool stop_gui_flag = false;

    // ARDUINO/EEG TRIGGERS (serial port connection)
    static EXP_class_SERIAL_PORT handler_trigger;

    static string serial_port_name;
    static bool send_trigger_flag;
    static bool use_touchdiver_flag; 


    private static void Main(string[] args)
    {
        Console.WriteLine($"{str_print}C# started");
        Parser.Default.ParseArguments<Options>(args)
                .WithParsed(options =>
                {
				    serial_port_name = $"COM{options.arduino_port}";
                    use_touchdiver_flag = options.use_diver;
                    send_trigger_flag = options.send_trigger;

                });
        
        Console.WriteLine(serial_port_name);
        
        // Create Serial port for trigger
        handler_trigger = new EXP_class_SERIAL_PORT(serial_port_name);                                                          
        handler_trigger.OpenSerialPort(send_trigger_flag);

        // Create the queue form storing the lists of int/float for the stimulation
        ConcurrentQueue<List<string>> command_queue = new();
        
        // COMMUNICATION THREAD - Command received from Python client_gui, handled and stored in the queue
        Task CommunicationTask = Task.Run(() => ManageCommunication(command_queue));
        // STIMULATION THREAD - Command dequeued from queue and used to provide stimulation
        Task StimulationTask = Task.Run(() => ManageStimulation(command_queue));

        // Await both tasks end
        Task TaskManager = Task.WhenAll(CommunicationTask, StimulationTask);
        TaskManager.Wait();

        // Close the serial port
        handler_trigger.CloseSerialPort(send_trigger_flag);
        handler_tcp_comm.CloseTcpConnection(stop_comm_flag, tcp_comm_port);
        handler_tcp_gui.CloseTcpConnection(stop_gui_flag, tcp_gui_port);

        Console.WriteLine($"{str_print}Both tasks completed");
    }
    // END Main


    static async void ManageCommunication(ConcurrentQueue<List<string>> primary_queue)
    {

        handler_tcp_comm = new EXP_class_TCP_COMMUNICATION(tcp_host, tcp_comm_port);
        TcpClient client_stim = handler_tcp_comm.OpenTcpConnection(tcp_comm_port);
        NetworkStream stream_stim = handler_tcp_comm.ClientGetStream(client_stim);

        handler_comm_thread = new EXP_class_HANDLE_COMMUNICATION();
        handler_comm_thread.CommandHandle(stream_stim, primary_queue, true);
        
    } // END MenageCommands

    static async void ManageStimulation(ConcurrentQueue<List<string>> storage_queue)
    {
        NetworkStream stream_gui;
        StreamWriter writer_gui; 
        handler_tcp_gui = new EXP_class_TCP_GUI(tcp_host, tcp_gui_port);
        stream_gui = handler_tcp_gui.ClientGetStream();
        writer_gui = handler_tcp_gui.ClientWriter(stream_gui);

        ConcurrentQueue<bool> flag_queue = new();
        Task KeyPressTask = Task.Run(() => KeyPressThread(flag_queue));

        handler_stim_thread = new EXP_class_HANDLE_STIMULATION();
        handler_stim_thread.StimulationHandle(storage_queue, flag_queue, handler_trigger, send_trigger_flag, stream_gui, writer_gui, use_touchdiver_flag);
    } // END ManageStimulation

    static async void KeyPressThread(ConcurrentQueue<bool> flag_queue)
    {
        int count_flag = 0;
        while (true)
        {
            ConsoleKeyInfo keyInfo = Console.ReadKey(true);
            if (keyInfo.Key == ConsoleKey.Enter)
            {
                count_flag++;
                if (count_flag % 2 != 0)
                {
                    bool flag_key = true;

                    Console.WriteLine($"          Pressed key to stop ({(count_flag+1)/2})");
                    flag_queue.Enqueue(flag_key);
                }
            }
        }
    }
}