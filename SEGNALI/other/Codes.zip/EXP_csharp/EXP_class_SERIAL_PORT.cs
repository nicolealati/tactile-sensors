﻿using System.IO.Ports; 

namespace EXP_csharp
{
    public class EXP_class_SERIAL_PORT
    {
        private SerialPort serialPort;
        private string str_print = "(SERIAL_PORT) ";
        public EXP_class_SERIAL_PORT(string portName, int baudRate = 9600)
        {
            serialPort = new SerialPort(portName, baudRate);
        }

        public void OpenSerialPort(bool trigger_flag)
        {
            if (trigger_flag)
            {
                Console.WriteLine($"\n{str_print}Opening serial port at port {serialPort.PortName}");
                serialPort.Open();
                serialPort.Write(IntToByteArray(0), 0, 4);
                //return serialPort;
                Console.WriteLine($"{str_print}Serial port open at {serialPort.PortName}\n");
            }
            else
            {
                Console.WriteLine($"\n{str_print}OpenSerialPort flag = false\n");
            }
        }

        public void CloseSerialPort(bool trigger_flag)
        {
            if (trigger_flag)
            {
                Console.WriteLine($"\n{str_print}Closing serial port {serialPort.PortName}");
                serialPort.Close();
                Console.WriteLine($"{str_print}Serial port closed\n");
            }
            else
            {
                Console.WriteLine($"\n{str_print}CloseSerialPort flag = false\n");
            }
        }

        public void SendSerialTrigger(bool trigger_flag, int intMsg)
        {
            if (trigger_flag)
            {
                byte[] msgBytes = IntToByteArray(intMsg);
                serialPort.Write(msgBytes, 0, msgBytes.Length);

                // TO MODIFY 100 MS AND TEST
                Thread.Sleep(100);
                //
                serialPort.Write(IntToByteArray(0), 0, 4);
                Console.WriteLine($"{str_print}                     Trigger sent: {intMsg}");
            }
            else
            {
                Console.WriteLine($"{str_print}                     Trigger sent (flag = false): {intMsg}");
            }
        }

        private byte[] IntToByteArray(int intVal)
        {
            byte[] intBytes = BitConverter.GetBytes(intVal);
            if (BitConverter.IsLittleEndian)
                Array.Reverse(intBytes);
            return intBytes;
        }
    }
}