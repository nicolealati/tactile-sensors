import sys
from PyQt5 import QtGui
from PyQt5.QtWidgets import QWidget, QLabel, QLineEdit, QVBoxLayout, QPushButton

class SubjectID(QWidget):
    def __init__(self):
        super().__init__()
        self.WindowSetup()

    def WindowSetup(self):
        self.setWindowTitle('Subject ID GUI')
        self.setGeometry(700, 400, 300, 200)

        font = QtGui.QFont()
        font.setPointSize(11)

        self.subject_number_label = QLabel('Subject ID:')
        self.subject_number_label.setFont(font)
        self.subject_number_edit = QLineEdit(self)
        self.subject_number_edit.setFont(font)

        self.submit_button = QPushButton('SUBMIT', self)
        self.submit_button.setFont(font)
        self.submit_button.setStyleSheet('background-color: lightgray;')
        self.submit_button.clicked.connect(self.SubmitData)

        self.empty_label = QLabel('')
        self.empty_label.setFont(font)

        layout = QVBoxLayout()
        layout.addWidget(self.subject_number_label)
        layout.addWidget(self.subject_number_edit)
        layout.addWidget(self.empty_label)
        layout.addWidget(self.submit_button)

        self.setLayout(layout)

    def SubmitData(self):
        self.submit_button.setEnabled(False)
        self.subject_ID = f"subject_{self.subject_number_edit.text()}"
        self.close()

        return self.subject_ID

