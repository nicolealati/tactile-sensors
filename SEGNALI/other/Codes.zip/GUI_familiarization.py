from PyQt5 import QtGui
from PyQt5.QtWidgets import QWidget, QLabel, QVBoxLayout, QHBoxLayout, QPushButton

class FamiliarizationWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.WindowSetup()


    def WindowSetup(self):
        self.setWindowTitle('Familiarization GUI')
        self.setGeometry(700, 400, 400, 300)

        font = QtGui.QFont()
        font.setPointSize(12)

        self.label = QLabel('Select a stimulation:')
        self.label.setFont(font)

        self.empty_label = QLabel('  ')
        self.empty_label.setFont(font)

        self.min_force_button = QPushButton("\nMin force\n", self)
        self.min_force_button.setFont(font)
        self.min_force_button.setStyleSheet('background-color: #ce873f;')
        self.min_force_button.clicked.connect(self.MinForceSelection)

        self.max_force_button = QPushButton("\nMax Force\n", self)
        self.max_force_button.setFont(font)
        self.max_force_button.setStyleSheet('background-color: #ce873f;')
        self.max_force_button.clicked.connect(self.MaxForceSelection)

        self.low_freq_button = QPushButton("\nLow frequency\n", self)
        self.low_freq_button.setFont(font)
        self.low_freq_button.setStyleSheet('background-color: #ce873f;')
        self.low_freq_button.clicked.connect(self.LowFrequencySelection)

        self.high_frequency_button = QPushButton("\nHigh frequency\n", self)
        self.high_frequency_button.setFont(font)
        self.high_frequency_button.setStyleSheet('background-color: #ce873f;')
        self.high_frequency_button.clicked.connect(self.HighFrequencySelection)

        self.close_button = QPushButton("Close window", self)
        self.close_button.setFont(font)
        self.close_button.setStyleSheet('background-color: lightgrey;')
        self.close_button.clicked.connect(self.CloseWindowSelection)

        force_layout = QHBoxLayout()
        force_layout.addWidget(self.min_force_button)
        force_layout.addWidget(self.max_force_button)
        frequency_layout = QHBoxLayout()
        frequency_layout.addWidget(self.low_freq_button)
        frequency_layout.addWidget(self.high_frequency_button)

        layout = QVBoxLayout()
        layout.addWidget(self.label)
        layout.addLayout(force_layout)
        layout.addLayout(frequency_layout)
        layout.addWidget(self.empty_label)
        layout.addWidget(self.close_button)
        
        self.setLayout(layout)

    def MinForceSelection(self):
        self.min_force_button.setEnabled(False)
        self.selection = 'min'
        self.CloseFunction()

    def MaxForceSelection(self):
        self.max_force_button.setEnabled(False)
        self.selection = 'max'
        self.CloseFunction()
    
    def LowFrequencySelection(self):
        self.low_freq_button.setEnabled(False)
        self.selection = 'low'
        self.CloseFunction()
    
    def HighFrequencySelection(self):
        self.high_frequency_button.setEnabled(False)
        self.selection = 'high'
        self.CloseFunction()
        
    def CloseWindowSelection(self):
        self.close_button.setEnabled(False)
        self.selection = 'stop'
        self.CloseFunction()
        
    
    def CloseFunction(self):
        self.close()
        return self.selection


