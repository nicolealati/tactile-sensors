from PyQt5 import QtGui
from PyQt5.QtWidgets import QWidget, QLabel, QLineEdit, QHBoxLayout, QVBoxLayout, QPushButton

class NumberRepetitions(QWidget):
    def __init__(self):
        super().__init__()
        self.WindowSetup()

    def WindowSetup(self):
        self.setWindowTitle('N reps GUI')
        self.setGeometry(700, 400, 250, 200)

        font = QtGui.QFont()
        font.setPointSize(11)

        self.request_label = QLabel("Insert n. repetitions:")
        self.request_label.setFont(font)

        self.reps_edit = QLineEdit(self)
        self.reps_edit.setFont(font)

        self.submit_button = QPushButton('SUBMIT', self)
        self.submit_button.setFont(font)
        self.submit_button.setStyleSheet('background-color: lightgray;')
        self.submit_button.clicked.connect(self.SubmitData)

        self.empty_label = QLabel("")
        self.error_label = QLabel("")

        layout_horizontal = QHBoxLayout()
        layout_horizontal.addWidget(self.request_label)
        layout_horizontal.addWidget(self.reps_edit)
        

        layout_vertical = QVBoxLayout()
        layout_vertical.addWidget(self.empty_label)
        layout_vertical.addLayout(layout_horizontal)
        layout_vertical.addWidget(self.error_label)
        layout_vertical.addWidget(self.submit_button)

        self.setLayout(layout_vertical)

    def SubmitData(self):
        self.submit_button.setEnabled(False)
        self.nreps = int(self.reps_edit.text())
        self.close()
        return self.nreps



